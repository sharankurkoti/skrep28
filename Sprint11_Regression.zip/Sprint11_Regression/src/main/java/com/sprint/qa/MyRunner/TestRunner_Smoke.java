package com.sprint.qa.MyRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
  @CucumberOptions(
		features = {
//				"src/test/resources/features/SM01_SubscriptionSearchEngine.feature",
//				"src/test/resources/features/SM02_Hyperlinks.feature",
//				"src/test/resources/features/SM03_SubscriptionsDetails.feature",
//				"src/test/resources/features/SM04_ChangeRequestDetails.feature",
//				"src/test/resources/features/SM05_ChangeReplaceDetails.feature",
//				"src/test/resources/features/SM06_TrueForwardChangeDetails.feature",
//				"src/test/resources/features/SM07_VendorInvoiceListPageDetails.feature",
//				"src/test/resources/features/SM08_CreateSubscriptionVendorInvoice.feature",
//				"src/test/resources/features/SM09_VendorCreateCreditMemo.feature",
//				"src/test/resources/features/SM10_CreateCustomerInvoiceDetails.feature",
//				"src/test/resources/features/SM11_SubscriptionInvoiceListPageDetails.feature",
//				"src/test/resources/features/SM12_Initiate_Renewal_Details.feature",
//				"src/test/resources/features/SM13_Initiate_Renewal_Modify_Details.feature",
				},
		glue={""},//the path of the step definition files
		//tags = {"~@Ignore"},
		plugin = {"pretty",
				"html:target/cucumber-reports/cucumber-pretty.html",
				"rerun:target/cucumber-reports/rerun.txt",
		        "json:target/cucumber-reports/CucumberTestReport.json"},
				//to generate different type of reporting
		monochrome = true, //display the console o/p in proper readable format
		dryRun = false,//to check the mapping is proper between feature file and step def file
		stepNotifications = true
		)

public class TestRunner_Smoke {
	
//	private TestNGCucumberRunner testNGCucumberRunner;
//	
//	@BeforeClass(alwaysRun = true)
//	public void setUpClass() throws Exception{
//		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//	}
//	
//	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
//	public void feature(CucumberFeatureWrapper cucumberFeature) {
//		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
//		//testNGCucumberRunner.runScenario(null);
//
}
//	
//	
//	@DataProvider
//	public Object[][] features(){
//		return testNGCucumberRunner.provideScenarios();
//	}
//
//	@AfterClass(alwaysRun = true)
//	public void tearDownClass() {
//		testNGCucumberRunner.finish();
//	}
//}