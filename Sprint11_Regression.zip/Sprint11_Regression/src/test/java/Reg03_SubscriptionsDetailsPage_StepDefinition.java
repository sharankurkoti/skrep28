import java.util.Calendar;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.SimpleDateFormat;
import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Reg03_SubscriptionsDetailsPage_StepDefinition extends TestBase{
	
	TestUtil testUtil;
	static String date1;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public Reg03_SubscriptionsDetailsPage_StepDefinition() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	public void setUp() throws Exception 
	{
		initialization();		
	}
	
	@Given("^SDetails user navigates to subscriptions page$")
	public void SDetails_user_navigates_to_subscriptions_page() throws Exception 
	{	
	    TestBase.initialization();	    
		
		Thread.sleep(8000);
	}

	@Then("^SDetails title of the login page is Subscriptions$")
	public void SDetails_title_of_login_page_is_Subscriptions() throws InterruptedException 
	{
		String title = driver.getTitle();
		log.info(title);
		Assert.assertEquals("Dashboard", title);
		Thread.sleep(6000);
		log.info("title of the login page is Subscriptions");
	}

	@And("^SDetails user clicks on left menu subs link$")
	public void SDetails_user_clicks_on_left_menu_subs_link() throws InterruptedException
	{
		Actions action = new Actions(driver);
		
		WebElement subscriptions_leftmenu = driver.findElement(By.xpath("//ul/li/a[@href='#/subscriptions']"));
		action.moveToElement(subscriptions_leftmenu).click().perform();

		Thread.sleep(3000);
		log.info("User clicks on left menu subscriptions link");
		
	}

	@And("^SDetails user is on Subscription page$")
	public void SDetails_user_is_on_Subscription_page() throws InterruptedException 
	{
		String str = driver.getTitle();
		log.info(str);
		Thread.sleep(3000);
		log.info("User is on Subscription page");
	}

	@And("^SDetails user enters subscription number$")
	public void SDetails_user_enters_subscription_number() throws InterruptedException 
	{
		Actions action = new Actions(driver);		
		Thread.sleep(5000);
			
		WebElement sub_num = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[1]/input"));
		sub_num.clear();
		action.moveToElement(sub_num).click().perform();
		sub_num.sendKeys(prop.getProperty("reg03_subNum"));
		
		Thread.sleep(3000);
		log.info("User selects subsnum from dropdown and enters subsnum successfully");
	}

	@And("^SDetails user clicks on search button$")
	public void SDetails_user_clicks_on_search_button() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[2]/div[2]/div/button[3]"));
		search_button.click();
		Thread.sleep(5000);
		log.info("User clicks on search button successfully");
	}

	@And("^SDetails user clicks on hyperlink of subscription number column$")
	public void SDetails_user_clicks_on_hyperlink_of_subscription_number_column() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[4]/div/div[2]/div[1]/table/tbody/tr[1]/td[2]/a"))).perform();
		WebElement hyper_link1= driver.findElement(By.xpath("//div[4]/div/div[2]/div[1]/table/tbody/tr[1]/td[2]/a"));
		hyper_link1.click();

		Thread.sleep(5000);
		log.info("User clicks on hyperlink of subscription number column successfully");
	}

	@And("^SDetails user is on Subscriptions details page and validates the status and title$")
	public void SDetails_user_is_on_Subscriptions_details_page_and_validates_the_status_and_title() throws InterruptedException{
		String uri = driver.getCurrentUrl();
		log.info("("+uri+")");

		driver.switchTo().defaultContent();
		String url = driver.getCurrentUrl();
		log.info("("+url+")");

		Set<String> allHandles = driver.getWindowHandles();

		for(String currWindow : allHandles)
		{
			driver.switchTo().window(currWindow);
			Thread.sleep(1000);
			String url1 = driver.getCurrentUrl();
			log.info("("+url1+")");
		}
		log.info("User switches to subscription details page successfully");
		
		String url2 = driver.getCurrentUrl();
		log.info("("+url2+")");
		Thread.sleep(6000);
	}

	@And("^SDetails user checks fields start date end date and initial term are editable$") 
	public String SDetails_user_checks_fields_start_date_end_date_and_initial_term_are_editable() throws InterruptedException {
		Actions action = new Actions(driver); 
		
		//select customer site admin
		WebElement drpdown = driver.findElement(By.xpath("//*[@id=\"customerSiteAdmin\"]"));
		action.moveToElement(drpdown).click().perform();
		Thread.sleep(3000);
		
		Select cust_site_admin = new Select(driver.findElement(By.xpath("//*[@id=\"customerSiteAdmin\"]")));
		cust_site_admin.selectByIndex(4);
		log.info("customer site admin selected succesfully");
		Thread.sleep(3000);
		
		//click on title
		WebElement subs_title = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/h4/span"));
		subs_title.click();
		Thread.sleep(1000);

		//validate dates
		WebElement start_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[2]/div[2]/div[2]/div[1]/div/input"));
		String isenabled = start_date.getAttribute("isenabled");
		Assert.assertNull(isenabled);

		WebElement end_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[2]/div[3]/div[2]/div[1]/div/input"));
		String isenabled1 = end_date.getAttribute("isenabled");
		Assert.assertNull(isenabled1);
		log.info("start date and end date validated succesfully");

		WebElement initial_term = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[3]/div[3]/div[2]/input"));
		String isenabled2 = initial_term.getAttribute("isenabled");
		Assert.assertNull(isenabled2);
		log.info("Initial term validated succesfully");
		Thread.sleep(2000);
		
        //update end date
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		log.info("Today's date is "+dateFormat.format(cal.getTime()));
		cal.add(Calendar.DATE, -1);
		log.info("Yesterday's date was "+dateFormat.format(cal.getTime())); 

		date1 = dateFormat.format(cal.getTime()); 

		WebElement end_date_icon = driver.findElement(By.xpath("//div[2]/div[3]/div[2]/div[1]/div/input"));
		action.moveToElement(end_date_icon).sendKeys(date1);
		Thread.sleep(8000);
		
		return date1;
	}

	@And("^SDetails user clicks on general information tab$") 
	public void SDetails_user_clicks_on_general_information_tab() throws InterruptedException {		
		WebElement gen_info_tab = driver.findElement(By.xpath("//div/ul/li/a[@href='#Information']"));
		gen_info_tab.click();

		Thread.sleep(5000);
		log.info("User clicks on general information tab and selects customer site admin succesfully");
	}

	@And("^SDetails user clicks on history tab and is empty$") 
	public void SDetails_user_clicks_on_history_tab_and_is_empty() throws InterruptedException {

		WebElement hist_tab_rec = driver.findElement(By.xpath("//div[2]/div/div/div[3]/div/ul/li[3]/a"));
		hist_tab_rec.click();

		WebElement no_records = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div/div[2]/div[3]/div/table/tbody/tr/td"));
		String str = no_records.getText();
		Assert.assertEquals("No records found.",str);		

		Thread.sleep(5000);
		log.info("User clicks on history tab and is empty succesfully");
	}

	@And("^SDetails user clicks on subscription details tab and selects start date$")
	public void SDetails_user_clicks_on_subscription_details_tab_and_selects_start_date() throws InterruptedException {
		Actions action = new Actions(driver);
		
		WebElement sub_details_tab1 = driver.findElement(By.xpath("//div/ul/li/a[@href='#Subscription']"));
		action.moveToElement(sub_details_tab1).click().perform();
		Thread.sleep(4000);

        //update start date

		WebElement str_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[2]/div[2]/div[2]/div[1]/div/input"));
		str_date.sendKeys(date1);
		Thread.sleep(8000);

		WebElement save_button = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/button[1]"));
		save_button.click();
		Thread.sleep(8000);

		log.info("User clicks on subscription details tab and selects start date succesfully");
	}

	@And("^SDetails clicks on more actions selects appropriate available option till status becomes active$") 
	public void SDetails_clicks_on_more_actions_selects_appropriate_available_option_till_status_becomes_active() throws InterruptedException {

		for(int i=0; i<=3; i++)  {

			WebElement sub_details_tab4 = driver.findElement(By.xpath("//div[2]/div/div/div[3]/div/ul/li[1]/a"));
			sub_details_tab4.click();

			WebElement more_actions4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/div/button"));
			more_actions4.click();
			Thread.sleep(3000);

			WebElement drpdown_item4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/div/div/a"));
			drpdown_item4.click();
			Thread.sleep(5000);

			try 
			{
				WebElement save_button4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/button[1]"));
				save_button4.click();
			}
			catch(org.openqa.selenium.StaleElementReferenceException ex)
			{
				WebElement save_button4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/button[1]"));
				save_button4.click();
			}

			Thread.sleep(3000);
			
		}
		log.info("Subscription status moved to Active successfully");

	}

	@And("^SDetails user validates active status on subscriptions details page$") 
	public void SDetails_user_validates_active_status_on_subscriptions_details_page() throws InterruptedException {
		WebElement Status1 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div[1]/h4/span"));
		String str = Status1.getText();
		Assert.assertEquals("Active", str);
		log.info("Subscription is in Acive status");

		Thread.sleep(6000);
		log.info("User validates active status on subscriptions details page successfully");
	}

	@And("^SDetails checks all the other fields start date end date and initial term are non editable$") 
	public void SDetails_checks_all_the_other_fields_start_date_end_date_and_initial_term_are_non_editable() throws InterruptedException {
		WebElement Status1 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div[1]/h4/span"));
		String str = Status1.getText();

		if(str == "Active") 
		{

			WebElement start_date = driver.findElement(By.xpath("//div[2]/div/div[2]/div[2]/div[2]/div[1]/div/input"));
			String isenabled = start_date.getAttribute("isenabled");
			Assert.assertNull(isenabled);


			WebElement end_date = driver.findElement(By.xpath("//div[2]/div[1]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div[1]/div/input"));
			String isenabled1 = end_date.getAttribute("isenabled");
			Assert.assertNull(isenabled1);

			WebElement initial_term = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[3]/div[3]/div[2]/input"));
			String isenabled2 = initial_term.getAttribute("isenabled");
			Assert.assertNull(isenabled2);

			Thread.sleep(3000);

		}
		log.info("User checks all the other fields start date end date and initial term are non editable successfully");
	}


	@And("^SDetails user clicks on history tab and validates record exists$")
	public void SDetails_user_clicks_on_history_ab_and_validates_record_exists() throws InterruptedException {

		WebElement hist_tab_rec = driver.findElement(By.xpath("//div[2]/div/div/div[3]/div/ul/li[3]/a"));
		hist_tab_rec.click();

		WebElement records_exists = driver.findElement(By.xpath("//div[3]/div[1]/table/tbody/tr[1]/td[2]"));
		String str = records_exists.getText();
		Assert.assertEquals("New Subscription", str);	

		Thread.sleep(6000);
		log.info("User clicks on history tab and validates record exists successfully");
	}

	@And("^SDetails user gets the subscription number and switches to parent window and validates status$")
	public void SDetails_user_gets_the_subsciprtion_number_and_closes_the_first_browser_for_view_details_page() throws InterruptedException {

		Thread.sleep(6000);

		WebElement sub_num = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/h4/span"));
		String sub_num1 = sub_num.getText();
		String sub_num2 = null;

		Pattern p = Pattern.compile("\\d+");
		Matcher m = p.matcher(sub_num1);
		while(m.find()) 
		{
			log.info(m.group());
			sub_num2 = m.group();
			log.info(sub_num2);
		}

		Thread.sleep(6000);

		Set<String> allWindowHandles = driver.getWindowHandles();
		for (@SuppressWarnings("unused") String handle : allWindowHandles) {
			driver.switchTo().window(allWindowHandles.iterator().next());
		}

		String url3 = driver.getCurrentUrl();
		log.info(url3);

		//enter subscription number
		WebElement enter_subnumber = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[1]/input"));
		enter_subnumber.clear();
		Thread.sleep(3000);
		enter_subnumber.sendKeys(prop.getProperty("reg03_subNum"));	
		Thread.sleep(3000);
		
		//click on title
		WebElement title_text = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/h4"));
		title_text.click();
		Thread.sleep(3000);

		//click search
		WebElement search1_button = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[2]/div[2]/div/button[3]"));
		search1_button.click();
		Thread.sleep(3000);

		//check the status column
		WebElement statuscg = driver.findElement(By.xpath("//div[4]/div/div[2]/div[1]/table/tbody/tr/td[4]/span"));
		String status = statuscg.getText();
		Assert.assertEquals("Active", status);

		Thread.sleep(6000);
		log.info("User gets the subscription number and switches to parent window and validates status successfully");
	}

	@Then("^SDetails user comes back to subscription details page and close the browser$")
	public void SDetails_user_comes_back_to_subscription_page_and_validates_the_record_is_in_active_status() throws InterruptedException {

		driver.switchTo().defaultContent();

		String parentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for (String childWindow : Allhandles) {

			driver.switchTo().window(childWindow);

			String url4 = driver.getCurrentUrl();
			log.info(url4);
		}

		driver.close();
		log.info("closing the subscription details tab successfully");

		driver.switchTo().window(parentWindow);
	}

	@And("^SDetails user clicks on user account dropdown$")
	public void SDetails_user_clicks_on_user_account_dropdown() throws InterruptedException {
		driver.switchTo().activeElement();

		Actions action = new Actions(driver);

		WebElement Drpdwn = driver.findElement(By.xpath("//*[@id=\"page-header-user-dropdown\"]"));
		action.moveToElement(Drpdwn).click().perform();

		Thread.sleep(3000);
		log.info("user clicks on user account dropdown successfully");
	}

	@And("^SDetails user clicks on logout$")
	public void SDetails_user_clicks_on_logout() {
		Actions action = new Actions(driver);
		
		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();		
		
		log.info("logged out successfully");
	}

	@And("^SDetails close the browser$")
	public void SDetails_close_the_browser() {
		driver.quit();
		
		log.info("close the final browser successfully");
	}
}