import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.SimpleDateFormat;
import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Reg10_CreateCustomerInvoiceDetails_StepDefinition extends TestBase {

	TestUtil testUtil;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);
	public static String date1;

	public Reg10_CreateCustomerInvoiceDetails_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	public String generateRandomString1() {
		return "sk_Test_" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	public String generateRandomString2() {
		return "sk_Test_" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	@Given("^CCI user logs into application$")
	public void CCI_user_logs_into_application() throws Exception 
	{	
		TestBase.initialization();	    
		Thread.sleep(8000);
	}

	@Then("^CCI user clicks on dropdown icon of vendor invoice$")
	public void CCI_user_clicks_on_dropdown_icon_of_vendor_invoice() throws InterruptedException {
		Actions action = new Actions(driver);

		try 
		{
			WebElement Vinvoice_icon = driver.findElement(By.xpath("//a[@href='#/subscription-vendor-invoices']"));
			action.moveToElement(Vinvoice_icon).perform();
			Vinvoice_icon.click();
		}
		catch(Exception e)
		{
			WebElement Vinvoice_icon = driver.findElement(By.xpath("//a[@href='#/subscription-vendor-invoices']"));
			action.moveToElement(Vinvoice_icon).perform();
			Vinvoice_icon.click();
		}

		Thread.sleep(3000);
		log.info("User clicks on left menu icon vendor invoices link successfully");
	}

	@Then("^CCI user clicks on vendor invoice list link$")  
	public void CCI_user_clicks_on_vendor_invoice_list_link() throws InterruptedException {

		Thread.sleep(3000);
		
	}

	@Then("^CCI user validates the title of the page and filters subscriptions$")
	public void CCI_user_validates_the_title_of_the_page_and_filters_subscriptions() throws InterruptedException {
		String str1 = driver.getTitle();
		Assert.assertEquals("Vendor Invoice", str1);

		Thread.sleep(3000);
		log.info("User validates title of the vendor invoice page successfully");		
	}


	@Then("^CCI user clicks on create invoice button$")
	public void CCI_user_clicks_on_create_invoice_button() throws InterruptedException {
		Actions action = new Actions(driver);

		try 
		{
			WebElement create_invoice_btn = driver.findElement(By.xpath("//button[contains(text(),'Create Invoice')]"));
			action.moveToElement(create_invoice_btn).perform();
			create_invoice_btn.click();
		}
		catch(Exception e)
		{
			WebElement create_invoice_btn = driver.findElement(By.xpath("//button[contains(text(),'Create Invoice')]"));
			action.moveToElement(create_invoice_btn).perform();
			create_invoice_btn.click();
		}

		Thread.sleep(3000);	
		log.info("User clicks on create invoice button successfully");
	}

	@Then("^CCI user navigates to create vendor invoice page$") 
	public void CCI_user_navigates_to_create_vendor_invoice_page() throws InterruptedException {

		driver.switchTo().defaultContent();
		//		String parentWindow = driver.getWindowHandle();
		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);

			String url = driver.getCurrentUrl();
			System.out.println(url);
			Thread.sleep(1000);
		}

		String str = driver.getTitle();
		Assert.assertEquals("Create Vendor Invoice", str);
		System.out.println();

		Thread.sleep(4000);
		log.info("User validates title of the create vendor invoice page successfully");
	}

	@Then("^CCI user navigates to vid tab and validates the page$")
	public void CCI_user_navigates_to_vid_tab_and_validates_the_page() throws InterruptedException {
		Actions action = new Actions(driver); 

		//CSVI user enters invoice number
		WebElement invoice_number = driver.findElement(By.xpath("//*[@id='col1']/div/div[1]/div[1]/div[2]/div/input"));
		invoice_number.sendKeys(generateRandomString1());
		Thread.sleep(3000);

		//CSVI user vendor name number and clicks search icon
		WebElement vendor_name= driver.findElement(By.xpath("//div[2]/div[2]/div/div[1]/input"));
		action.moveToElement(vendor_name).click().perform();
		vendor_name.clear();
		vendor_name.sendKeys(prop.getProperty("vendor_name"));
		Thread.sleep(3000);

		WebElement search_btn1 = driver.findElement(By.xpath("//i[@class='fas fa-search']"));
		search_btn1.click();

		try 
		{
			List<WebElement> options = driver.findElements(By.xpath("//ul/li[@class='autocomplete-result']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Cisco Systems, Inc. [CISC01]")){
					option.click();
				}

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options = driver.findElements(By.xpath("//ul/li[@class='autocomplete-result']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Cisco Systems, Inc. [CISC01]")){
					option.click();
				}

			}
		}

		Thread.sleep(3000);
		log.info("Vendor name updated Successfully");

		//select on payment terms
		WebElement pay_terms_drpdwn = driver.findElement(By.xpath("//div/div[2]/div[1]/div[2]/div/select"));
		pay_terms_drpdwn.click();
		Thread.sleep(3000);

		Select payment_terms = new Select(driver.findElement(By.xpath("//div/div[2]/div[1]/div[2]/div/select")));
		payment_terms.selectByIndex(14);
		log.info("Payment terms selected Successfully");
		Thread.sleep(3000);

		//user selects date for invoice date and date received
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Today's date is "+dateFormat.format(cal.getTime()));
		String date_today = dateFormat.format(cal.getTime()); 
		date1 = date_today;
		cal.add(Calendar.DATE, -1);
		System.out.println("Yesterday's date was "+dateFormat.format(cal.getTime())); 
		@SuppressWarnings("unused")
		String date2 = dateFormat.format(cal.getTime()); 

		//invoice date
		WebElement inv_date = driver.findElement(By.xpath("//div/div[3]/div[1]/div[2]/div/div[1]/div/input"));
		inv_date.sendKeys(date1);
		Thread.sleep(3000);
		log.info("Invoice date field updated Successfully");

		//Date Received 
		WebElement date_received = driver.findElement(By.xpath("//div[3]/div[2]/div[2]/div/div[1]/div/input"));
		date_received.sendKeys(date1);
		Thread.sleep(3000);
		log.info("Date received field updated Successfully");

		//click on title contract vehicle
		WebElement title_head = driver.findElement(By.xpath("//div[2]/div/div/div[1]/h4/span"));
		title_head.click();
		Thread.sleep(3000);
		log.info("Title head clicked Successfully");

		//CSVI user clicks on save button
		WebElement save_btn = driver.findElement(By.xpath("//div/button[contains(text(),'Save')]"));
		save_btn.click();
		Thread.sleep(3000);
		log.info("Clicked on Save button Successfully");

		//CCM user scrolls down to the page
		Thread.sleep(3000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollTo(0,document.body.scrollHeight)","");

		//CCM user clicks on three dots to add line items
		WebElement three_dots1 = driver.findElement(By.xpath("//*[@id=\"dropdownMenuButton\"]/i"));
		action.moveToElement(three_dots1).click().perform();
		Thread.sleep(3000);
		log.info("Clicked on 3 dots Successfully");

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@href='javascript:void(0)'][@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Add Item")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@href='javascript:void(0)'][@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Add Item")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		//enter subscription number	
		driver.switchTo().activeElement();
		WebElement subs_num =  driver.findElement(By.xpath("//div[2]/div/div[1]/div/div/div[2]/div[1]/input"));
		subs_num.clear();
		subs_num.sendKeys(prop.getProperty("reg10_subNum"));
		log.info("Entered the subscription number Successfully");

		WebElement search_btn = driver.findElement(By.xpath("//button/i[@class='fa fa-search']"));
		search_btn.click();
		Thread.sleep(3000);
		log.info("Clicked on search button Successfully");

		//add line items
		WebElement add_line_items_chkbx = driver.findElement(By.xpath("//div[2]/div/div/div/table/thead/tr/th[1]/div/span/input"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", add_line_items_chkbx);
		log.info("Line items added Successfully");
		Thread.sleep(3000);

		WebElement add_close_btn = driver.findElement(By.xpath("//button[contains(text(),'Add & Close')]"));
		add_close_btn.click();
		Thread.sleep(3000);
		log.info("Clicked on add and close button Successfully");

		//CCM user navigates to top of the page
		Thread.sleep(3000);
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");
		Thread.sleep(3000);

		//move the status of invoice to manually received
		WebElement more_actions_drpdwn1 = driver.findElement(By.xpath("//div[4]/div/div/div[1]/div/div[1]/div/div[2]/div/div/div[2]/button"));
		more_actions_drpdwn1.click();
		Thread.sleep(3000);
		log.info("Clicked on more actions button Successfully");

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Manually Received")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Manually Received")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		Thread.sleep(7000);
		log.info("User moves the status to manually received successfully");

		//move the status of invoice to manually received
		//click on more actions button
		try 
		{
			WebElement more_actions_drpdwn2 = driver.findElement(By.xpath("//div[4]/div/div/div[1]/div/div[1]/div/div[2]/div/div/div[2]/button"));
			more_actions_drpdwn2.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			WebElement more_actions_drpdwn2 = driver.findElement(By.xpath("//div[4]/div/div/div[1]/div/div[1]/div/div[2]/div/div/div[2]/button"));
			more_actions_drpdwn2.click();
			Thread.sleep(3000);
		}
		log.info("Clicked on more actions button Successfully");

		//select create subscription invoice from dropdown
		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Create Subscription Invoice")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Create Subscription Invoice")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		Thread.sleep(3000);
		log.info("User select option create subscription invoice successfully");

		//click on view details button
		//		driver.switchTo().activeElement();

		try 
		{
			WebElement view_details_btn = driver.findElement(By.xpath("//div/div[1]/div/div[4]/div/div/div/div/div[3]/button"));
			view_details_btn.click();
		}
		catch(Exception e)
		{
			WebElement view_details_btn = driver.findElement(By.xpath("//div/div[1]/div/div[4]/div/div/div/div/div[3]/button"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", view_details_btn);
		}
		Thread.sleep(7000);		
		log.info("User clicks on view details button successfully");
	}

	@Then("^CCI user navigates to create customer invoice page$")
	public void CCI_user_moves_the_status_to_manually_received() throws InterruptedException {
		Actions action = new Actions(driver);
		driver.switchTo().defaultContent();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);

			String url = driver.getCurrentUrl();
			System.out.println(url);

			Thread.sleep(1000);
		}
		log.info("User navigated to create customer invoice successfully");

		//move the customer create invoice status to submitted for payment 
		WebElement more_actions_drpdwn = driver.findElement(By.xpath("//*[@id=\"btnGroupVerticalDropCustomerInvoice\"]"));
		more_actions_drpdwn.click();
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Create Credit Memo")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Create Credit Memo")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}		
		Thread.sleep(3000);
		log.info("clicked on Create Credit Memo successfully");

	}

	@Then("^CCI user clicks on create credit memo button$")
	public void CCI_user_clicks_on_create_credit_memo_button() throws InterruptedException {

		Thread.sleep(3000);
		log.info("User clicks on create credit memo successfully");
	}

	@Then("^CCI user navigates to subscription credit memo page and validate flows$")
	public void CCI_user_navigates_to_subscription_credit_memo_page_and_validate_flows() throws InterruptedException {
		Actions action = new Actions(driver);
		driver.switchTo().defaultContent();

		//String parentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);

			String url = driver.getCurrentUrl();
			System.out.println(url);

			Thread.sleep(1000);
		}		
		log.info("User navigates to create credit memo page successfully");

		//Enter title of the credit memo
		WebElement cm_title = driver.findElement(By.xpath("//div/div[1]/div[2]/div[2]/div/input"));
		cm_title.sendKeys(generateRandomString2());
		Thread.sleep(3000);

		//clicks on save button
		WebElement save_btn = driver.findElement(By.xpath("//div/button[contains(text(), 'Save')]"));
		action.moveToElement(save_btn).perform();
		save_btn.click();
		log.info("User saves the credit memo page successfully");
		Thread.sleep(3000);

		//add line items
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("window.scrollTo(0,document.body.scrollHeight)","");

		//CCM user clicks on three dots to add line items
		WebElement three_dots1 = driver.findElement(By.xpath("//*[@id=\"dropdownMenuButton\"]/i"));
		action.moveToElement(three_dots1).click().perform();
		Thread.sleep(3000);
		log.info("Clicked on 3 dots Successfully");

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//div[@class='dropdown-menu show']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Add Line Item")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//div[@class='dropdown-menu show']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Add Line Item")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		//enter subscription number	
		driver.switchTo().activeElement();
		WebElement subs_num =  driver.findElement(By.xpath("//div[2]/div/div[1]/div/div/div[2]/div[1]/input"));
		subs_num.clear();
		subs_num.sendKeys(prop.getProperty("reg10_subNum"));
		log.info("Entered the subscription number Successfully");

		WebElement search_btn = driver.findElement(By.xpath("//button/i[@class='fa fa-search']"));
		search_btn.click();
		Thread.sleep(3000);
		log.info("Clicked on search button Successfully");

		//add line items
		WebElement add_line_items_chkbx = driver.findElement(By.xpath("//div[2]/div/div/div/table/thead/tr/th[1]/div/span/input"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", add_line_items_chkbx);
		log.info("Line items added Successfully");
		Thread.sleep(3000);

		WebElement add_close_btn = driver.findElement(By.xpath("//button[contains(text(),'Add & Close')]"));
		add_close_btn.click();
		Thread.sleep(3000);

		Thread.sleep(3000);
		log.info("User adds the line items successfully");

		//change the status to submitted for payment
		//move the customer create invoice status to submitted for payment 
		JavascriptExecutor js3 = (JavascriptExecutor) driver;
		js3.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");
		Thread.sleep(3000);

		//validate that status is submitted for payment
		WebElement status_cmemo = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div/h4/span"));
		String str = status_cmemo.getText();
		Assert.assertEquals("Submitted To ERP", str);
		Thread.sleep(3000);	
		log.info("Successfully validated the status is Submitted for Payment");

		for(@SuppressWarnings("unused") String currwindow1 : Allhandles) {
			driver.switchTo().window(Allhandles.iterator().next());
			Thread.sleep(2000);
		}
		log.info("Successfully switched to vendor invoice page");
		Thread.sleep(5000);

	}

	@Then("^CCI user navigates to vendor invoice page and clicks on hyperlink of credit memo$")
	public void CCI_user_navigates_to_vendor_invoice_page_and_clicks_on_hyperlink_of_credit_memo() throws InterruptedException{
		Actions action = new Actions(driver);

		//filter for document type and subscription vendor invoice credit memo 
		WebElement Drpdwn = driver.findElement(By.xpath("//div[5]/div[1]/div[2]/div/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[5]/div[1]/div[2]/div/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Subscription Vendor Invoice Credit Memo");

		//filter for status = submitted for payment
		WebElement Drpdwn2 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
		action.moveToElement(Drpdwn2).click().perform();

		List<WebElement> options = driver.findElements(By.xpath("//li[@class='multiselect__element']"));				
		for(WebElement option : options) {
			if(option.getText().trim().contains("Submitted For Payment")) {
				action.moveToElement(option).click().perform();
			}
		}

		Thread.sleep(3000);

		WebElement rand_opt = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/h4"));
		rand_opt.click();

		Thread.sleep(2000);

		WebElement Drpdwn22 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
		action.moveToElement(Drpdwn22).click().perform();

		Thread.sleep(6000);

		WebElement DrpdwnAnyOption33 =driver.findElement(By.xpath("//*[@id=\"layout-wrapper\"]/div[2]/div/div/div[3]/div/div[1]/div[4]/div[1]/div[2]/div/div[1]/div/div[3]/ul/li[1]/span/span"));		
		DrpdwnAnyOption33.click();
		Thread.sleep(3000);

		WebElement rand_opt2 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/h4"));
		rand_opt2.click();

		Thread.sleep(2000);

		//click on search button
		WebElement search_butn = driver.findElement(By.xpath("//button[contains(text(),'Search')]/i[@class='fas fa-search']"));
		action.moveToElement(search_butn).click().perform();
		Thread.sleep(3000);

		//clicks on hyperlink of first column and new page opens
		WebElement document_hyperlink = driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]/a/a[@class='order-link']"));
		action.moveToElement(document_hyperlink).click().perform();
		Thread.sleep(3000);

	}

	@Then("^CCI user navigates to credit memo page second time$")
	public void CCI_user_naviagtes_to_credit_memo_page_second_time() throws InterruptedException{
		Actions action = new Actions(driver);
		driver.switchTo().defaultContent();

		//String parentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);

			String url = driver.getCurrentUrl();
			System.out.println(url);

			Thread.sleep(1000);
		}	

		//user selects generate subscription credit memo from more actions
		WebElement more_actions_drpdwn1 = driver.findElement(By.xpath("//button/i[@class='mdi mdi-chevron-down']"));
		more_actions_drpdwn1.click();

		Thread.sleep(3000);

		List<WebElement> optionss4 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for(WebElement option : optionss4) {
			if(option.getText().trim().contains("Generate Subscription Credit Memo")) {
				action.moveToElement(option).perform();
				option.click();
			}
		}

		Thread.sleep(3000);
	}

	@And("^CCI user navigates to subscription credit memo page$")
	public void CCI_user_navigates_to_subscription_credit_memo_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String parentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);

			String url = driver.getCurrentUrl();
			System.out.println(url);

			Thread.sleep(1000);
		}	

		//click on add line item button and validate the subs#

		WebElement addlineitem_btn =  driver.findElement(By.xpath("//button/i[@class='fas fa-plus']"));
		addlineitem_btn.click();

		Thread.sleep(3000);

		WebElement close_btn = driver.findElement(By.xpath("//button[contains(text(),'Close')]/i[@class='fas fa-times']"));
		close_btn.click();

		Thread.sleep(3000);

	}

	@And("^CCI user close the second subs credit memo page$") 
	public void CCI_user_close_the_second_subs_credit_memo_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//driver.close();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);

		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);

		}

	}

	@And("^CCI user close the credit memo page$") 
	public void CCI_user_close_the_credit_memo_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//driver.close();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);

		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);

		}

	}

	@And("^CCI user close the first subs credit memo page$") 
	public void CCI_user_close_the_first_subs_credit_memo_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//driver.close();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);

		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);

		}

	}

	@And("^CCI user close the customer invoice details page$")
	public void CCI_user_close_the_customer_invoice_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//driver.close();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
		}
	}


	@And("^CCI user close the vendor invoice details page$")
	public void CCI_user_close_the_vendor_invoice_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//driver.close();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
		}
	}

	@And("^CCI user clicks on logout$")
	public void CCI_user_clicks_on_logout() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//*[@id='page-header-user-dropdown']"))).click().perform();
		Thread.sleep(2000);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();
	}

	@And("^CCI close the browser$")
	public void CCI_close_the_browser() {
		driver.quit();
	}

}