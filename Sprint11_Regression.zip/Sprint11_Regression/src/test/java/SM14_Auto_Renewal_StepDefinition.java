import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SM14_Auto_Renewal_StepDefinition extends TestBase {
	TestUtil testUtil;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public SM14_Auto_Renewal_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	public String generateRandomString() {
		return "Sk_RenMod_Test" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	@Given("^SMAR User logs into application$")
	public void SMAR_User_logs_into_application() throws Exception 
	{	
		TestBase.initialization();	    

		Thread.sleep(8000);
		log.info("User logs into application page");
	}

	@When("^SMAR title of the login page is Subscriptions$")
	public void SMAR_title_of_login_page_is_Subscriptions() 
	{
		String title = driver.getTitle();
		System.out.println(title);
		log.info("title of the login page is validated successfully");
	}

	@Then("^SMAR User clicks on subscriptions link on left menu$")
	public void SMAR_User_clicks_on_subscriptions_link_on_left_menu() throws InterruptedException 
	{
		Actions action = new Actions(driver);		
		action.moveToElement(driver.findElement(By.xpath("//ul/li/a[@href='#/subscriptions']"))).click().perform();
		Thread.sleep(3000);
		log.info("User clicks on subscriptions link on left menu successfully");
	}

	@And("^SMAR User is on Subscription page$")
	public void SMAR_User_is_on_Subscription_page() throws InterruptedException 
	{

		String title = driver.getTitle();
		System.out.println(title);

		log.info("User is on Subscription page");
		Thread.sleep(6000);

	}

	@And("^SMAR User search the subscription number$")
	public void SMAR_User_search_the_subscription_number() throws InterruptedException 
	{
		Actions action = new Actions(driver);

		WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div/div[1]/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Subs #");

		Thread.sleep(5000);

		WebElement sub_num = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div/div[1]/input"));
		sub_num.clear();
		sub_num.sendKeys(prop.getProperty("reg14_subNum"));

		log.info("User search the subscription number");
		Thread.sleep(3000);
	}

	@And("^SMAR User clicks on search button$")
	public void SMAR_User_clicks_on_search_button() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();

		log.info("User clicks on search button");
		Thread.sleep(3000);
	}

	@And("^SMAR User clicks on hyperlink of the subscription number$")
	public void SMAR_User_clicks_on_hyperlink_of_the_subscription_number() throws InterruptedException {
		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[2]/div[1]/table/tbody/tr/td[2]/a"))).click().perform();
		Thread.sleep(3000);
		log.info("User clicks on hyperlink of the subscription number successfully");
	}

	@And("^SMAR User clicks on view details button$")
	public void SMAR_User_clicks_on_view_details_button() throws InterruptedException {
		driver.switchTo().activeElement();
		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'View Details')]"))).click().perform();

		Thread.sleep(3000);
		log.info("User clicks on view details button successfully");
	}


	@And("^SMAR User navigates to sub details page$") 
	public void SMAR_User_navigates_to_sub_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String pentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);
			String url = driver.getCurrentUrl();
			System.out.println(url);
			Thread.sleep(1000);
		}

		Thread.sleep(3000);
		log.info("User navigates to view detials page successfully");
	}

	@And("SMAR User clicks on related documents tab")
	public void SMAR_User_clicks_on_related_documents_tab() throws InterruptedException {
		Actions action = new Actions(driver); 

		action.moveToElement(driver.findElement(By.xpath("//li/a[@href='#RelatedDocuments']"))).click().perform();

		Thread.sleep(3000);
		log.info("User clicks on related documents tab successfully");
	}

	@And("SMAR User clicks on change order hyperlink")
	public void SMAR_User_clicks_on_change_order_hyperlink() throws InterruptedException {
		Actions action = new Actions(driver); 

		action.moveToElement(driver.findElement(By.xpath("//div[3]/div[1]/table/tbody/tr/td[1]/a"))).click().perform();

		Thread.sleep(3000);
		log.info("User clicks on change order hyperlink successfully");
	}

	@And("^SMAR User navigates to change request page$") 
	public void SMAR_User_navigates_to_change_request_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String pentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);
			String url = driver.getCurrentUrl();
			System.out.println(url);
			Thread.sleep(3000);
		}

		Thread.sleep(3000);
		log.info("User navigates to change request page successfully");
	}

	@And("^SMAR User validates automatic renewal message$")
	public void SMAR_User_validates_automatic_renewal_message() throws InterruptedException {

		Thread.sleep(3000);
		log.info("User validates automatic renewal message successfully");
	}

	@And("^SMAR User validates change type value$")
	public void SMAR_User_validates_change_type_value() throws InterruptedException {

		Thread.sleep(3000);
		log.info("User validates change type value successfully");
	}

	@And("^SMAR User close the change request details page$")
	public void SMAR_User_close_the_change_request_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();
		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {
			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(3000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(3000);
		}
		log.info("User close the change request details page successfully");
	}

	@And("^SMAR User close the subscriptions details page$") 
	public void SMAR_User_close_the_subscription_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(3000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(3000);

			log.info("User close the subscriptions details page successfully");
		}

	}

	@And("^SMAR User clicks on logout$")
	public void SMAR_User_clicks_on_logout() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//*[@id='page-header-user-dropdown']"))).click().perform();
		Thread.sleep(5000);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();

		log.info("User clicks on logout successfully");
	}

	@And("^SMAR close the browser$")
	public void SMAR_close_the_browser() {
		driver.quit();
		log.info("Close the browser successfully");
	}
}