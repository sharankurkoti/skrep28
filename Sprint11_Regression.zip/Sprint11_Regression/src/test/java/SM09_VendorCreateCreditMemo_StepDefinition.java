import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.SimpleDateFormat;
import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class SM09_VendorCreateCreditMemo_StepDefinition extends TestBase {

	TestUtil testUtil;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);
	public static String date1;

	public SM09_VendorCreateCreditMemo_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	public String generateRandomString1() {
		return "Sk_vInvoice" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	public String generateRandomString2() {
		return "Sk_cMemo" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	@Given("^SMVCCM user logs into application$")
	public void SMVCCM_user_logs_into_application() throws Exception 
	{	
		TestBase.initialization();	    
		Thread.sleep(8000);
	}

	@Then("^SMVCCM user clicks on dropdown icon of vendor invoice$")
	public void SMVCCM_user_clicks_on_dropdown_icon_of_vendor_invoice() throws InterruptedException {

		WebElement Vinvoice_icon = driver.findElement(By.xpath("//ul/li/a[@href='#/subscription-vendor-invoices']"));
		Vinvoice_icon.click();

		log.info("User clicks on left menu icon vendor invoices link successfully");
		Thread.sleep(3000);
	}

	@Then("^SMVCCM user clicks on vendor invoice list link$")  
	public void SMVCCM_user_clicks_on_vendor_invoice_list_link() throws InterruptedException {

		Thread.sleep(3000);
	}

	@Then("^SMVCCM user validates the title of the page and filters subscriptions$")
	public void SMVCCM_user_validates_the_title_of_the_page_and_filters_subscriptions() throws InterruptedException {

		Thread.sleep(3000);
	}

	@Then("^SMVCCM user clicks on create invoice button$")
	public void SMVCCM_user_clicks_on_create_invoice_button() throws InterruptedException {
		Actions action = new Actions(driver);

		WebElement create_invoice_btn = driver.findElement(By.xpath("//button[contains(text(),'Create Invoice')]"));
		action.moveToElement(create_invoice_btn).perform();
		create_invoice_btn.click();

		Thread.sleep(3000);		
	}

	@Then("^SMVCCM user navigates to create vendor invoice page$") 
	public void SMVCCM_user_navigates_to_create_vendor_invoice_page() throws InterruptedException {

		driver.switchTo().defaultContent();
		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {
			driver.switchTo().window(childWindow1);
			Thread.sleep(3000);
		}

		Thread.sleep(3000);
	}

	@Then("^SMVCCM user navigates to vid tab and validates the page$")
	public void SMVCCM_user_navigates_to_vid_tab_and_validates_the_page() throws InterruptedException {
		Actions action = new Actions(driver); 

		//CSVI user enters invoice number
		WebElement invoice_number = driver.findElement(By.xpath("//*[@id='col1']/div/div[1]/div[1]/div[2]/div/input"));
		invoice_number.sendKeys(generateRandomString1());

		Thread.sleep(3000);

		//CSVI user vendor name number and clicks search icon
		WebElement vendor_name= driver.findElement(By.xpath("//div[2]/div[2]/div/div[1]/input"));
		action.moveToElement(vendor_name).click().perform();
		vendor_name.clear();
		vendor_name.sendKeys(prop.getProperty("vendor_name"));
		Thread.sleep(3000);

		WebElement search_btn1 = driver.findElement(By.xpath("//i[@class='fas fa-search']"));
		search_btn1.click();

		try 
		{
			List<WebElement> options = driver.findElements(By.xpath("//ul/li[@class='autocomplete-result']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Cisco Systems, Inc. [CISC01]")){
					option.click();
				}

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options = driver.findElements(By.xpath("//ul/li[@class='autocomplete-result']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Cisco Systems, Inc. [CISC01]")){
					option.click();
				}

			}
		}

		Thread.sleep(3000);
		log.info("Vendor name updated Successfully");

		//select on payment terms
		WebElement pay_terms_drpdwn = driver.findElement(By.xpath("//div/div[2]/div[1]/div[2]/div/select"));
		pay_terms_drpdwn.click();
		Thread.sleep(3000);

		Select payment_terms = new Select(driver.findElement(By.xpath("//div/div[2]/div[1]/div[2]/div/select")));
		payment_terms.selectByIndex(14);
		log.info("Payment terms selected Successfully");

		Thread.sleep(3000);

		//user selects date for invoice date and date received
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		log.info("Today's date is "+dateFormat.format(cal.getTime()));
		String date_today = dateFormat.format(cal.getTime()); 
		date1 = date_today;
		cal.add(Calendar.DATE, -1);
		log.info("Yesterday's date was "+dateFormat.format(cal.getTime())); 
		@SuppressWarnings("unused")
		String date2 = dateFormat.format(cal.getTime()); 

		//invoice date
		WebElement inv_date = driver.findElement(By.xpath("//div/div[3]/div[1]/div[2]/div/div[1]/div/input"));
		inv_date.sendKeys(date1);
		Thread.sleep(3000);

		//Date Received 
		WebElement date_received = driver.findElement(By.xpath("//div[3]/div[2]/div[2]/div/div[1]/div/input"));
		date_received.sendKeys(date1);
		Thread.sleep(3000);

		//click on title contract vehicle
		WebElement title_head = driver.findElement(By.xpath("//div[2]/div/div/div[1]/h4/span"));
		title_head.click();
		Thread.sleep(3000);

		//CSVI user clicks on save button
		WebElement save_btn = driver.findElement(By.xpath("//div/button[contains(text(),'Save')]"));
		save_btn.click();
		Thread.sleep(3000);
		log.info("Clicked on Save button Successfully");

		//CCM user navigates to top of the page
		Thread.sleep(3000);
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");
		Thread.sleep(3000);

		//click on create credit memo from more actions tab
		WebElement more_actions_drpdwn = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/div/div[2]/button"));
		more_actions_drpdwn.click();
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Create Credit Memo")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Create Credit Memo")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		Thread.sleep(3000);
		log.info("User selects create credit memo option successfully");		
	}

	@Then("^SMVCCM user navigates to create credit memo page$")
	public void SMVCCM_user_navigates_to_create_credit_memo_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String parentWindow = driver.getWindowHandle();
		Set<String> Allhandles = driver.getWindowHandles();
		for( String childWindow1 : Allhandles) {
			driver.switchTo().window(childWindow1);
			Thread.sleep(2000);
		}
		log.info("User navigates to create credit memo page successfully");
		Thread.sleep(3000);
	}

	@Then("^SMVCCM user enters credit memo number and saves it$") 
	public void SMVCCM_user_enters_credit_memo_number_and_saves_it() throws InterruptedException{
		Actions action = new Actions(driver);
		//enter credit memo #
		WebElement creditmemo_num = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[1]/div[1]/div[2]/div/input"));
		creditmemo_num.clear();
		creditmemo_num.sendKeys(generateRandomString2());
		Thread.sleep(3000);
		log.info("User enters the credit memo number successfully");
		
		//Enter credit memo date, Date received and posting date
		WebElement ccm_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[3]/div[1]/div[2]/div/div[1]/div/input")); 
		ccm_date.sendKeys(date1);
		Thread.sleep(4000);
		log.info("User enters the credit memo date successfully");
		
		WebElement date_received = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[3]/div[2]/div[2]/div/div[1]/div/input")); 
		date_received.sendKeys(date1);
		Thread.sleep(4000);
		log.info("User enters the credit memo date received fiekd successfully");
		
		WebElement posting_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[3]/div[3]/div[2]/div/div[1]/div/input")); 
		posting_date.sendKeys(date1);
		Thread.sleep(4000);
		log.info("User enters the posting date field successfully");
		
		//click on save and close popup
		WebElement save_btn = driver.findElement(By.xpath("//div/button[contains(text(), 'Save')]"));
		action.moveToElement(save_btn).perform();
		save_btn.click();
		//close the popup
		Thread.sleep(3000);
		log.info("User saves the credit memo page successfully");
	}

	@Then("^SMVCCM user validates line items from cmemo to vid page$")
	public void SMVCCM_user_validates_line_items_from_cmemo_to_vid_page() throws InterruptedException{
		Actions action = new Actions(driver);

		JavascriptExecutor js3 = (JavascriptExecutor) driver;
		js3.executeScript("window.scrollTo(0,document.body.scrollHeight)","");
		Thread.sleep(3000);

		//CCM user clicks on three dots to add line items
		WebElement three_dots1 = driver.findElement(By.xpath("//*[@id=\"dropdownMenuButton\"]/i"));
		action.moveToElement(three_dots1).click().perform();
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@href='javascript:void(0)'][@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Add Item")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@href='javascript:void(0)'][@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Add Item")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		//enter subscription number	
		driver.switchTo().activeElement();
		WebElement subs_num =  driver.findElement(By.xpath("//div[2]/div/div[1]/div/div/div[2]/div[1]/input"));
		subs_num.clear();
		subs_num.sendKeys(prop.getProperty("sm09_subNum"));
		log.info("Entered the subscription number Successfully");
		
		WebElement search_btn = driver.findElement(By.xpath("//button/i[@class='fa fa-search']"));
		search_btn.click();
		Thread.sleep(3000);
		log.info("User clicked on search icon successfully");
		
		//add line items
		WebElement add_line_items_chkbx = driver.findElement(By.xpath("//div[2]/div/div/div/table/thead/tr/th[1]/div/span/input"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", add_line_items_chkbx);
	
		Thread.sleep(3000);

		WebElement add_close_btn = driver.findElement(By.xpath("//button[contains(text(),'Add & Close')]"));
		add_close_btn.click();
		Thread.sleep(3000);
		log.info("Line items added Successfully");

		//move the status of credit memo
		JavascriptExecutor js5 = (JavascriptExecutor) driver;
		js5.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");

		WebElement more_actions_drpdwn = driver.findElement(By.xpath("//button/i[@class='mdi mdi-chevron-down']"));
		action.moveToElement(more_actions_drpdwn).click();
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Submit for Reimbursement")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Submit for Reimbursement")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		Thread.sleep(3000);	
		log.info("Status of credit memo moved to 'submit for reimbursement' Successfully");
		
		//move the credit memo status to submitted for payment
		WebElement more_actions_drpdwn4 = driver.findElement(By.xpath("//button/i[@class='mdi mdi-chevron-down']"));
		action.moveToElement(more_actions_drpdwn4).click();
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Submit to ERP")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Submit to ERP")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		Thread.sleep(8000);
		log.info("Moved the credit memo status to 'submitted for payment' Successfully");
	}

	@And("^SMVCCM user close the credit memo page$") 
	public void SMVCCM_user_close_the_credit_memo_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();
		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
		}
		log.info("closed the credit memo page Successfully");
	}

	@And("^SMVCCM user close the vendor invoice details page$")
	public void SMVCCM_user_close_the_vendor_invoice_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();
		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
		}
		log.info("closed the vendor invoice page Successfully");
	}

	@And("^SMVCCM user clicks on logout$")
	public void SMVCCM_user_clicks_on_logout() throws InterruptedException {
		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//*[@id=\"page-header-user-dropdown\"]"))).click().perform();
		Thread.sleep(3000);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();
		log.info("Clicked on logout option Successfully");
	}

	@And("^SMVCCM close the browser$")
	public void SMVCCM_close_the_browser() {
		driver.quit();
		log.info("closed the browser Successfully");
	}
}