import java.math.BigInteger;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class SM12_Initiate_Renewal_Details_StepDefinition extends TestBase {
	TestUtil testUtil;
	public static String date1;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public SM12_Initiate_Renewal_Details_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	public String generateRandomString() {
		return "Sk_CRep_Test" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	@Given("^user logs into application SMIR$")
	public void user_logs_into_application_SMIR() throws Exception 
	{	
		TestBase.initialization();	    
		Thread.sleep(8000);
	}

	@Then("^title of the login page is Subscriptions SMIR$")
	public void title_of_login_page_is_Subscriptions_SMIR() 
	{
		log.info("User valdiates the title");
	}

	@And("^user clicks on view details link SMIR$")
	public void user_clicks_on_view_details_link_SMIR() 
	{
		driver.findElement(By.xpath("//a[@class='order-link']/a[@href='#/subscriptions?status=1']")).click();
	}

	@And("^user is on Subscription page SMIR$")
	public void user_is_on_Subscription_page_SMIR() throws InterruptedException 
	{
		//WebElement Subscr_page = driver.findElement(By.xpath("//h4[contains(text(),'Subscription')]"));

		log.info("User is on subscription page");
		Thread.sleep(6000);
	}

	@And("^user clicks on subscription dropdown selects dropdown value SMIR$")
	public void user_clicks_on_subscription_dropdown_selects_dropdown_value_SMIR() throws InterruptedException 
	{
		Actions action = new Actions(driver);

		WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div/div[1]/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Subs #");

		Thread.sleep(5000);

		WebElement sub_num = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div/div[1]/input"));
		sub_num.clear();
		sub_num.sendKeys(prop.getProperty("sm12_subNum"));

		log.info("User clicks on subscription dropdown selects dropdown value");
		Thread.sleep(3000);
	}

	@And("^user clicks on second dropdown and select status active SMIR$")
	public void user_clicks_on_second_dropdown_and_select_status_active_SMIR() throws InterruptedException {

		Thread.sleep(3000);
	}

	@And("^user clicks on search button SMIR$")
	public void user_clicks_on_search_button_SMIR() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();

		log.info("User clicks on search button");
		Thread.sleep(3000);
	}

	@And("^user navigates to actions column and click on dots and selects an option SMIR$")
	public void user_navigates_to_actions_column_and_click_on_dots_and_selects_an_option_SMIR() throws InterruptedException {
		Actions action = new Actions(driver);

		WebElement head_title = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/h4"));
		head_title.click();
		Thread.sleep(3000);

		action.moveToElement(driver.findElement(By.xpath("//*[@id='dropdownMenuButton']"))).click().perform();
		Thread.sleep(3000);

		List<WebElement> options =    driver.findElements(By.cssSelector("a[href='javascript:void(0)'][class='dropdown-item']"));
		for(WebElement option : options) {
			if(option.getText().trim().contains("Initiate Renewal")) {
				action.moveToElement(option).click().perform();
			}
		}
		Thread.sleep(3000);
	}

	@And("^user select renew from popup window SMIR$")
	public void user_select_renew_from_popup_window_SMIR() throws InterruptedException {
		driver.switchTo().activeElement();
		Actions action = new Actions(driver);
		try
		{
			WebElement radio_button = driver.findElement(By.xpath("//div/label[@for='Renew'][@class='custom-control-label']"));
			action.click(radio_button).click().perform();
		}
		catch(Exception e)
		{
			WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div/div[1]/div[1]/div[1]/div[1]/select"));
			action.moveToElement(Drpdwn).click().perform();
			Drpdwn.click();
			Thread.sleep(3000);

			Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div/div[1]/div[1]/div[1]/div[1]/select")));		
			DrpdwnAnyOption.selectByVisibleText("Status");
			Thread.sleep(3000);

			WebElement Drpdwn1 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
			action.moveToElement(Drpdwn1).click().perform();

			List<WebElement> options = driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));

			for(WebElement option : options) {
				if(option.getText().trim().contains("Active")) {
					option.click();
				}
			}
			Thread.sleep(8000);

			WebElement Drpdwn2 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
			action.moveToElement(Drpdwn2).click().perform();

			WebElement selected_option = driver.findElement(By.xpath("//div[2]/div/div[1]/div/div[3]/ul/li[1]/span"));
			action.click(selected_option).perform();
			Thread.sleep(3000);

			WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
			search_button.click();
			Thread.sleep(3000);

			WebElement sort_desc = driver.findElement(By.xpath("//div[2]/div[1]/table/thead/tr/th[5]/div[2]/span/i"));
			action.click(sort_desc).perform();
			Thread.sleep(3000);

			action.moveToElement(driver.findElement(By.xpath("//*[@id='dropdownMenuButton']"))).build().perform();
			WebElement dots = driver.findElement(By.xpath("//*[@id='dropdownMenuButton']"));
			dots.click();

			List<WebElement> options1 =    driver.findElements(By.cssSelector("a[href='javascript:void(0)'][class='dropdown-item']"));
			for(WebElement option : options1) {
				if(option.getText().trim().contains("Initiate Renewal")) {
					option.click();
				}
			}

			//try to find the radio button once again
			WebElement radio_button = driver.findElement(By.xpath("//div/label[@for='Renew'][@class='custom-control-label']"));
			action.click(radio_button).click().perform();
		}

		Thread.sleep(3000);

		WebElement ok_button = driver.findElement(By.xpath("//div/button[contains(text(),'Ok')]"));
		ok_button.click();

		Thread.sleep(3000);
	}

	@And("^user navigates to change request page SMIR$") 
	public void user_navigates_to_change_request_page_SMIR() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String parentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);

			String url = driver.getCurrentUrl();
			log.info(url);

			Thread.sleep(1000);
		}

		//driver.switchTo().window(parentWindow);
		log.info("User navigates to change request page successfully");
		Thread.sleep(3000);
	}

	@And("update mandatory fields on cr page SMIR")
	public void update_mandatory_fields_on_cr_page_SMIR() throws InterruptedException {
		Actions action = new Actions(driver); 
		Thread.sleep(3000);

		WebElement title1 = driver.findElement(By.xpath("//div[@id='titleDiv']/input[@class='form-control']"));
		title1.sendKeys(generateRandomString());
		@SuppressWarnings("unused")
		String title2 = title1.getText();  
		Thread.sleep(3000);

		WebElement save_button1 = driver.findElement(By.xpath("//div[@id='Subscription']/div/div[1]/div/div[2]/div/button[1]"));
		action.moveToElement(save_button1).click().perform();
		Thread.sleep(3000);

		//update previous date to start date
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		log.info("Today's date is "+dateFormat.format(cal.getTime()));
		cal.add(Calendar.DATE, -1);
		log.info("Yesterday's date was "+dateFormat.format(cal.getTime())); 

		String date12 = dateFormat.format(cal.getTime()); 

		date1 = date12;
		Thread.sleep(3000);

		WebElement req_str_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[2]/div[1]/div[2]/div/div/input"));
		req_str_date.sendKeys(date1);
		Thread.sleep(3000);

		//navigate to change order details tab
		WebElement cod_tab2 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Information']"));
		action.moveToElement(cod_tab2).click().perform();

		//update change order info
		WebElement bill_to1 = driver.findElement(By.xpath("//*[@id=\"Informationdiv\"]/div/div[2]/div[1]/div[2]/select"));
		action.moveToElement(bill_to1).click().perform();
		Thread.sleep(3000);

		Select drp_dwn_anyoption1 = new Select(driver.findElement(By.xpath("//*[@id=\"Informationdiv\"]/div/div[2]/div[1]/div[2]/select")));
		drp_dwn_anyoption1.selectByIndex(1);
		Thread.sleep(3000);

		//update purchase order info
		WebElement bill_to2 = driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[2]/div[1]/div[2]/select"));
		action.moveToElement(bill_to2).click().perform();
		Thread.sleep(3000);

		Select drp_dwn_anyoption2 = new Select(driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[2]/div[1]/div[2]/select")));
		drp_dwn_anyoption2.selectByIndex(0);
		Thread.sleep(3000);

		// provide email id
		WebElement vend_title= driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[1]/div[1]/div[2]/label"));
		action.moveToElement(vend_title).click().perform();
		Thread.sleep(3000);

		WebElement email_id = driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[2]/div[2]/div[2]/input"));
		email_id.sendKeys(prop.getProperty("email_idd"));        
		Thread.sleep(5000);

		WebElement save_button2 = driver.findElement(By.xpath("//div/div/div[2]/div/div[2]/div/button[1]"));
		action.moveToElement(save_button2).click().perform();
		Thread.sleep(3000);
	}

	@And("^move the status to complete SMIR$")
	public void move_the_status_to_complete_SMIR() throws InterruptedException {
		Actions action = new Actions(driver); 

		//navigate to cr details tab
		//submit and validate cr number
		//scroll to top of the page
		JavascriptExecutor js777= (JavascriptExecutor) driver;
		js777.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");

		//navigate to cr details tab
		try {
			WebElement crd_tab5 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Subscription']"));
			action.moveToElement(crd_tab5).click().perform();
		}
		catch(Exception e) {
			WebElement crd_tab5 = driver.findElement(By.xpath("//div/ul/li/a[@href='#Subscription']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor. executeScript("arguments[0]. click();", crd_tab5);
		}

		log.info("click on crd tab successfully");
		Thread.sleep(3000);

		//submit and validate status
		try {
			WebElement more_actions_btn = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn);
		}
		log.info("click on more actions button successfully");
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Send")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Send")) 
				{
					JavascriptExecutor executor = (JavascriptExecutor)driver; 
					executor.executeScript("arguments[0].click();", option);
				}
			}
		}

		Thread.sleep(5000);		

		//add an opportunity
		WebElement link_opportunity =  driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div/a/i"));
		link_opportunity.click();
		Thread.sleep(3000);

		driver.switchTo().activeElement();

		WebElement radio_butn = driver.findElement(By.xpath("//table/tbody/tr[1]/td[1]/input"));
		radio_butn.click();

		WebElement link_button =  driver.findElement(By.xpath("//button[contains(text(),'Link')]"));
		link_button.click();

		log.info("opportunity added successfully");
		Thread.sleep(3000);

		//click on disable preorder
		try {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			action.moveToElement(disable_preorderV).click().perform();
		}
		catch(Exception e) {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", disable_preorderV);
		}

		log.info("clicked on disable preorder successfully");
		Thread.sleep(5000);

		//scroll to top of the page
		JavascriptExecutor js7777= (JavascriptExecutor) driver;
		js7777.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");
		Thread.sleep(3000);

		//move to next status
		try {
			WebElement more_actions_btn2 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn2).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn2 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn2);
		}

		Thread.sleep(4000);

		try 
		{
			List<WebElement> options2 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options2) 
			{
				if(option.getText().trim().contains("Send for Verification")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options2 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options2) 
			{
				if(option.getText().trim().contains("Send for Verification")) 
				{
					JavascriptExecutor executor = (JavascriptExecutor)driver; 
					executor.executeScript("arguments[0].click();", option);
				}
			}
		}

		//close popup button
		Thread.sleep(5000);		
		log.info("clicked on send for verification successfully");

		Thread.sleep(3000);

		// move to next status
		try {
			WebElement more_actions_btn4 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn4).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn4 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn4);
		}

		Thread.sleep(4000);

		try 
		{
			List<WebElement> options4 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options4) 
			{
				if(option.getText().trim().contains("Edit QC")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options4 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options4) 
			{
				if(option.getText().trim().contains("Edit QC")) 
				{
					JavascriptExecutor executor = (JavascriptExecutor)driver; 
					executor.executeScript("arguments[0].click();", option);
				}
			}
		}

		//edit QC information on popup
		driver.switchTo().activeElement();
		Thread.sleep(5000);

		log.info("clicked on Edit QC successfully");

		WebElement check_box1 = driver.findElement(By.xpath("//input[@id='8'][@type='checkbox']"));
		check_box1.click();

		WebElement check_box2 = driver.findElement(By.xpath("//input[@id='32'][@type='checkbox']"));
		check_box2.click();

		WebElement check_box3 = driver.findElement(By.xpath("//input[@id='512'][@type='checkbox']"));
		check_box3.click();

		WebElement check_box4 = driver.findElement(By.xpath("//input[@id='1024'][@type='checkbox']"));
		check_box4.click();
		log.info("User checks all check boxes successfully");

		//select QC Analyst
		WebElement Drpdwnqc = driver.findElement(By.xpath("//div[3]/div/div/div/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/select"));
		action.moveToElement(Drpdwnqc).click().perform();
		Drpdwnqc.click();

		Select DrpdwnAnyOptionqc = new Select(driver.findElement(By.xpath("//div[3]/div/div/div/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/select")));		
		DrpdwnAnyOptionqc.selectByIndex(3);
		log.info("User selects analyst from dropdown successfully");

		//enter text
		WebElement qc_note1 = driver.findElement(By.xpath("//div[3]/div/div/div/div/div[2]/div[2]/div/div[2]/div[4]/div[2]/textarea"));
		qc_note1.sendKeys(generateRandomString());
		Thread.sleep(3000);
		log.info("User provide qa note name successfully");

		WebElement release_verification = driver.findElement(By.xpath("//div/div[1]/div/div[3]/div/div/div/div/div[3]/button[2]"));
		release_verification.click();
		log.info("User clicks on release verificaiton button successfully");

		Thread.sleep(5000);		
		log.info("moved to credit hold status successfully");

		// move to next status
		try {
			WebElement more_actions_btn6 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn6).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn6 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn6);
		}

		Thread.sleep(3000);
		log.info("User clicks on more actions button successfully");

		try 
		{
			List<WebElement> options6 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options6) 
			{
				if(option.getText().trim().contains("Release Credit Hold")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options6 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options6) 
			{
				if(option.getText().trim().contains("Release Credit Hold")) 
				{
					JavascriptExecutor executor = (JavascriptExecutor)driver; 
					executor.executeScript("arguments[0].click();", option);
				}
			}
		}

		//close popup button
		Thread.sleep(5000);		
		log.info("selected relese credit hold status from dropdown successfully");
		log.info("moved to infulfillment status successfully");

		//click on disable preorder
		try {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			action.moveToElement(disable_preorderV).click().perform();
		}
		catch(Exception e) {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", disable_preorderV);
		}

		log.info("clicked on disable preorder successfully");
		Thread.sleep(6000);

		//scroll to top of the page
		JavascriptExecutor js77777= (JavascriptExecutor) driver;
		js77777.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");
		Thread.sleep(4000);

		// move to next status
		try {
			WebElement more_actions_btn7 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn7).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn7 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn7);
		}
		Thread.sleep(3000);
		log.info("User clicks on more actions button successfully");

		try 
		{
			List<WebElement> options7 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options7) 
			{
				if(option.getText().trim().contains("Submit")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options7 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options7) 
			{
				if(option.getText().trim().contains("Submit")) 
				{
					JavascriptExecutor executor = (JavascriptExecutor)driver; 
					executor.executeScript("arguments[0].click();", option);
				}
			}
		}

		//close popup button
		Thread.sleep(5000);		
		log.info("clicked on submit status successfully");

		Thread.sleep(3000);
		log.info("moved to submitted to vendor status successfully");

		// move to next status
		try {
			WebElement more_actions_btn9 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn9).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn9 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn9);
		}

		Thread.sleep(4000);
		log.info("User clicks on more actions button successfully");

		try 
		{
			List<WebElement> options9 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options9) 
			{
				if(option.getText().trim().contains("Pending Provisioning")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options9 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options9) 
			{
				if(option.getText().trim().contains("Pending Provisioning")) 
				{
					JavascriptExecutor executor = (JavascriptExecutor)driver; 
					executor.executeScript("arguments[0].click();", option);
				}
			}
		}

		//close popup button
		Thread.sleep(3000);		
		log.info("moved to pending provisioning status successfully");

		//validate manufacturer part with subscription detials page - customer details tab
		// move to next status

		//enter start date
		action.moveToElement(driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div/div[1]/div/input")));
		action.click();
		action.sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE);
		Thread.sleep(3000);			
		action.sendKeys(date1);
		Thread.sleep(3000);
		action.build().perform();
		log.info("User updates the start date field successfully");

		//enter end date        
		WebElement end_date = driver.findElement(By.xpath("//div[2]/div[3]/div[2]/div/div[1]/div/input"));
		end_date.sendKeys(date1);
		Thread.sleep(3000);
		log.info("User updates the end date field successfully");

		try {
			WebElement more_actions_btn10 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn10).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn10 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn10);
		}

		Thread.sleep(3000);
		log.info("User clicks on more actions tab successfully");

		try 
		{
			List<WebElement> options10 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options10) 
			{
				if(option.getText().trim().contains("Mark Complete")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options10 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options10) 
			{
				if(option.getText().trim().contains("Mark Complete")) 
				{
					JavascriptExecutor executor = (JavascriptExecutor)driver; 
					executor.executeScript("arguments[0].click();", option);
				}
			}
		}

		//close popup button
		Thread.sleep(5000);		
		log.info("Moved to complete successfully");

		WebElement history_tab6 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#History']"));
		action.moveToElement(history_tab6).click().perform();

		log.info("clicked on history tab successfully");
		Thread.sleep(8000);

		//click on crd tab
		try{
			WebElement crd_tab89 = driver.findElement(By.xpath("//div/ul/li/a[@href='#Subscription']"));
			action.moveToElement(crd_tab89).click().perform();

		} catch(Exception e){
			WebElement crd_tab89 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Subscription']"));
			action.moveToElement(crd_tab89).click().perform();
		}
		log.info("clicked on crd tab successfully");
		Thread.sleep(8000);

		//navigate to sub details page
		WebElement sub_hyperlink = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[1]/div[3]/div[2]/a"));
		sub_hyperlink.click();

		driver.switchTo().defaultContent();
		Set<String> allWindowHandles = driver.getWindowHandles();
		for ( String currHandle : allWindowHandles) {

			driver.switchTo().window(currHandle);
		}

		String url = driver.getCurrentUrl();
		log.info("("+url+")");

		//navigate to history tab
		Thread.sleep(3000);
		WebElement history_tab4 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#History']"));
		action.moveToElement(history_tab4).click().perform();

		log.info("clicked on history tab successfully");
		Thread.sleep(5000);
	}

	@And("^user close the subscriptions details page SMIR$") 
	public void user_close_the_subscription_details_page_SMIR() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();
		Set<String> allwindowhandles = driver.getWindowHandles();
		for(String currwindow : allwindowhandles) {
			driver.switchTo().window(currwindow);
		}

		driver.close();
		log.info("closing the subscription details tab successfully");

		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {
			driver.switchTo().window(allwindowhandles.iterator().next());
		}
		log.info("User moves to next tab successfully");
	}

	@And("^user close the change request details page SMIR$")
	public void user_close_the_change_request_details_page_SMIR() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();
		for(String currwindow : allwindowhandles) {
			driver.switchTo().window(currwindow);
		}

		driver.close();
		log.info("closing the change request details tab successfully");
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {
			driver.switchTo().window(allwindowhandles.iterator().next());
		}
		log.info("User moved to next tab successfully");
	}

	@And("^user clicks on logout SMIR$")
	public void user_clicks_on_logout_SMIR() throws InterruptedException {

		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//*[@id='page-header-user-dropdown']"))).click().perform();
		Thread.sleep(5000);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();
		log.info("logged out successfully");
	}

	@And("^close the browser SMIR$")
	public void close_the_browser_SMIR() {
		driver.quit();
		log.info("closed the browser successfully");
	}
}