import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class SM11_SubscriptionInvoiceListPage_StepDefinition extends TestBase {

	TestUtil testUtil;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public SM11_SubscriptionInvoiceListPage_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	@Given("^SMSIL user logs into application$")
	public void SMSIL_user_logs_into_application() throws Exception 
	{	

		TestBase.initialization();	    

		Thread.sleep(8000);	
		log.info("User logs into application successfully");

	}

	@Then("^SMSIL user clicks on dropdown icon of subscription invoice$")
	public void SMSIL_user_clicks_on_dropdown_icon_of_subscription_invoice() throws InterruptedException {

		Thread.sleep(3000);
	}

	@Then("^SMSIL user clicks on subscription invoice list link$")  
	public void SMSIL_user_clicks_on_subscription_invoice_list_link() throws InterruptedException {

		WebElement Vinvoicelistlink = driver.findElement(By.xpath("//ul/li/a[@href='#/subscription-invoices']"));
		Vinvoicelistlink.click();

		Thread.sleep(3000);
		log.info("User clicks on subscription invoice list link successfully");
	}

	@Then("^SMSIL user validates the title of the page$")
	public void SMSIL_user_validates_the_title_of_the_page() throws InterruptedException {

		Thread.sleep(3000);
		log.info("User validates the title of the page successfully");
	}

	@Then("^SMSIL user validates add and delete buttons$") 
	public void SMSIL_user_validates_add_and_delete_button() throws InterruptedException {
		WebElement deletefilter_link = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/i[2]"));
		deletefilter_link .click();
		Thread.sleep(3000);

		WebElement addfilter_link = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[3]/div[1]/div[2]/div/div/i[1]"));
		addfilter_link.click();
		Thread.sleep(3000);
		
		log.info("User validates add and delete button successfully");
	}

	@Then("^SMSIL user applies filters$")
	public void SMSIL_user_applies_filter() throws InterruptedException {
		Actions action = new Actions(driver);
		
		WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Status");

		Thread.sleep(5000);

		WebElement Drpdwn2 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
		action.moveToElement(Drpdwn2).click().perform();

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Submitted For Payment")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Submitted For Payment")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		log.info("User applies filter successfully");
	}

	@Then("^SMSIL user clicks on search button$") 
	public void SMSIL_user_clicks_on_search_button() throws InterruptedException {
		WebElement title_head = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/h4"));
		title_head.click();
		Thread.sleep(3000);


		WebElement search_button = driver.findElement(By.xpath("//div/button/i[@class=\"fas fa-search\"]"));
		search_button.click();

		Thread.sleep(3000);
		log.info("User clicks on search button successfully");

	}

	@Then("^SMSIL user validates reset link$") 
	public void SMSIL_user_validates_reset_button() throws InterruptedException {


		Thread.sleep(3000);
		log.info("User validates reset link successfully");	
	}

	@Then("^SMSIL user validates show entries$") 
	public void SMSIL_user_validates_show_entries() throws InterruptedException {

		Thread.sleep(3000);
		log.info("User validates show entries successfully");
	}

	@Then("^SMSIL user scrolls to bottom of the page$") 
	public void SMSIL_user_Scrolls_to_bottom_of_the_page() throws InterruptedException {

		JavascriptExecutor js6= (JavascriptExecutor) driver;
		js6.executeScript("window.scrollTo(0,document.body.scrollHeight)","");

		Thread.sleep(3000);
		log.info("User scrolls to botton of the page successfully");
	}

	@Then("^SMSIL user validate page navigation$") 
	public void SMSIL_user_validate_page_navigation() throws InterruptedException {

		WebElement nextpage_button = driver.findElement(By.xpath("//a[contains(text(),'Next')]"));					

		@SuppressWarnings("unused")
		boolean str11 = nextpage_button.isDisplayed();

		if(str11 = false) {

			nextpage_button.click();

		}else {
			System.out.print("Next button is disabled");
		}

		Thread.sleep(3000);	
		log.info("User validates page navigation successfully");
	}

	@And("^SMSIL user clicks on user account dropdown$")
	public void SMSIL_user_clicks_on_user_account_dropdown() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//button[@id='page-header-user-dropdown']"))).click().perform();

		Thread.sleep(5000);
		log.info("User clicks on user account dropdown successfully");
	}

	@And("^SMSIL user clicks on logout$")
	public void SMSIL_user_clicks_on_logout() {
		Actions action = new Actions(driver);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	

		action.moveToElement(logout).click().perform();
		log.info("User clicks on logout successfully");
	}

	@And("^SMSIL close the browser$")
	public void SMSIL_close_the_browser() {
		driver.quit();
		log.info("User close the browser successfully");
	}	

}