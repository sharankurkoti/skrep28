import java.util.Calendar;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.SimpleDateFormat;
import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class SM03_SubscriptionsDetailsPage_StepDefinition extends TestBase{
	
	TestUtil testUtil;
	static String date1;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public SM03_SubscriptionsDetailsPage_StepDefinition() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	public void setUp() throws Exception 
	{
		initialization();		
	}
	
	@Given("^SMSD user navigates to subscriptions page$")
	public void SMSD_user_navigates_to_subscriptions_page() throws Exception 
	{	
	    TestBase.initialization();	    
		
	    log.info("User navigates to subscriptions page");
		Thread.sleep(8000);
	}

	@Then("^SMSD title of the login page is Subscriptions$")
	public void SMSD_title_of_login_page_is_Subscriptions() throws InterruptedException 
	{
		String title = driver.getTitle();
		log.info("Title is subscriptions");
		Assert.assertEquals("Dashboard", title);
		
		log.info("Title of the login page is Subscriptions");
		Thread.sleep(6000);
	}

	@And("^SMSD user clicks on view details link$")
	public void SMSD_user_clicks_on_view_details_link() throws InterruptedException 
	{
//		driver.findElement(By.xpath("//div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/a[1]/a[1]")).click();
		log.info("User mouse hovers on left menu panel");
		Thread.sleep(3000);
	}

	@And("^SMSD user is on Subscription page$")
	public void SMSD_user_is_on_Subscription_page() throws InterruptedException 
	{
		
		Actions action = new Actions(driver);

		WebElement subscriptions_leftmenu = driver.findElement(By.xpath("//ul/li/a[@href='#/subscriptions']"));
		action.moveToElement(subscriptions_leftmenu).click().perform();

		log.info("User is on Subscription page");
		Thread.sleep(6000);
	}

	@And("^SMSD user selects subsnum from dropdown and enters subsnum$")
	public void SMSD_user_selects_subsnum_from_dropdown_and_enters_subsnum() throws InterruptedException 
	{
			
		WebElement sub_num = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[1]/input"));
		sub_num.sendKeys(prop.getProperty("sm03_subNum"));
		
		log.info("User selects subsnum from dropdown and enters subsnum");
		Thread.sleep(3000);
	}

	@And("^SMSD user clicks on second dropdown and selects option$")
	public void SMSD_user_clicks_on_second_dropdown_and_selects_option() throws InterruptedException {
		
		Thread.sleep(3000);
	}

	@And("^SMSD user clicks on search button$")
	public void SMSD_user_clicks_on_search_button() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[2]/div[2]/div/button[3]"));
		search_button.click();
		
		log.info("User clicks on search button");
		Thread.sleep(3000);
	}

	@And("^SMSD user clicks on hyperlink of subscription number column$")
	public void SMSD_user_clicks_on_hyperlink_of_subscription_number_column() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[4]/div/div[2]/div[1]/table/tbody/tr[1]/td[2]/a"))).perform();
		WebElement hyper_link1= driver.findElement(By.xpath("//div[4]/div/div[2]/div[1]/table/tbody/tr[1]/td[2]/a"));
		hyper_link1.click();
		
		log.info("User clicks on hyperlink of subscription number column");
		Thread.sleep(3000);
	}

	@And("^SMSD user observes window pop up and clicks on view details link$")
	public void SMSD_user_observes_window_pop_up_and_clicks_on_view_details_link() throws InterruptedException {

		log.info("User observes window pop up and clicks on view details link");
		Thread.sleep(3000);
	}

	@And("^SMSD user is on Subscriptions details page and validates the status and title$")
	public void SMSD_user_is_on_Subscriptions_details_page_and_validates_the_status_and_title() throws InterruptedException{
		String uri = driver.getCurrentUrl();
		log.info("("+uri+")");

		driver.switchTo().defaultContent();

		String url = driver.getCurrentUrl();
		log.info("("+url+")");

		Set<String> allHandles = driver.getWindowHandles();

		for(String currWindow : allHandles)
		{

			driver.switchTo().window(currWindow);
			Thread.sleep(3000);
			String url1 = driver.getCurrentUrl();
			log.info("("+url1+")");

		}

		String url2 = driver.getCurrentUrl();
		log.info("("+url2+")");

		log.info("User is on Subscriptions details page and validates the status and title");
		Thread.sleep(3000);
	}


	@And("^SMSD user checks fields start date end date and initial term are editable$") 
	public String SMSD_user_checks_fields_start_date_end_date_and_initial_term_are_editable() throws InterruptedException {
		Actions action = new Actions(driver); 
		
		//select customer site admin
		WebElement drpdown = driver.findElement(By.xpath("//*[@id=\"customerSiteAdmin\"]"));
		action.moveToElement(drpdown).click().perform();
		Thread.sleep(3000);
		
		Select cust_site_admin = new Select(driver.findElement(By.xpath("//*[@id=\"customerSiteAdmin\"]")));
		cust_site_admin.selectByIndex(4);
		log.info("customer site admin selected succesfully");
		Thread.sleep(3000);
		
		//click on title
		WebElement subs_title = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/h4/span"));
		subs_title.click();
		Thread.sleep(1000);
		
        //update end date
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		log.info("Today's date is "+dateFormat.format(cal.getTime()));
		cal.add(Calendar.DATE, -1);
		log.info("Yesterday's date was "+dateFormat.format(cal.getTime())); 

		date1 = dateFormat.format(cal.getTime()); 

		WebElement end_date_icon = driver.findElement(By.xpath("//div[2]/div[3]/div[2]/div[1]/div/input"));
		action.moveToElement(end_date_icon).sendKeys(date1);
		Thread.sleep(8000);
		
		return date1;
	}

	@And("^SMSD user clicks on general information tab and selects customer site admin$") 
	public void SMSD_user_clicks_on_general_information_tab_and_selects_customer_site_admin() throws InterruptedException {		
		WebElement gen_info_tab = driver.findElement(By.xpath("//div/ul/li/a[@href='#Information']"));
		gen_info_tab.click();
		
		log.info("User clicks on general information tab and selects customer site admin");
		Thread.sleep(5000);
	}

	@And("^SMSD user clicks on history tab and is empty$") 
	public void SMSD_user_clicks_on_history_tab_and_is_empty() throws InterruptedException {

		WebElement hist_tab_rec = driver.findElement(By.xpath("//div[2]/div/div/div[3]/div/ul/li[3]/a"));
		hist_tab_rec.click();

		log.info("User clicks on history tab and is empty");
		Thread.sleep(5000);
	}

	@And("^SMSD user clicks on subscription details tab and selects start date$")
	public void SMSD_user_clicks_on_subscription_details_tab_and_selects_start_date() throws InterruptedException {
		Actions action = new Actions(driver);
		
		WebElement sub_details_tab1 = driver.findElement(By.xpath("//div/ul/li/a[@href='#Subscription']"));
		action.moveToElement(sub_details_tab1).click().perform();

		Thread.sleep(4000);

        //update start date
		WebElement str_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[2]/div[2]/div[2]/div[1]/div/input"));
		str_date.sendKeys(date1);
		Thread.sleep(8000);

		WebElement save_button = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/button[1]"));
		save_button.click();

		log.info("User clicks on subscription details tab and selects start date");
		Thread.sleep(8000);
	}

	@And("^SMSD clicks on more actions selects appropriate available option till status becomes active$") 
	public void SMSD_clicks_on_more_actions_selects_appropriate_available_option_till_status_becomes_active() throws InterruptedException {

		for(int i=0; i<=3; i++)  {

			WebElement sub_details_tab4 = driver.findElement(By.xpath("//div[2]/div/div/div[3]/div/ul/li[1]/a"));
			sub_details_tab4.click();

			WebElement more_actions4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/div/button"));
			more_actions4.click();
			Thread.sleep(3000);

			WebElement drpdown_item4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/div/div/a"));
			drpdown_item4.click();
			Thread.sleep(5000);

			try 
			{
				WebElement save_button4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/button[1]"));
				save_button4.click();
			}
			catch(org.openqa.selenium.StaleElementReferenceException ex)
			{
				WebElement save_button4 = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div[1]/div/div[1]/div/button[1]"));
				save_button4.click();
			}

			log.info("User clicks on more actions selects appropriate available option till status becomes active");
			Thread.sleep(3000);
		}

	}

	@And("^SMSD user validates active status on subscriptions details page$") 
	public void SMSD_user_validates_active_status_on_subscriptions_details_page() throws InterruptedException {
		WebElement Status1 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div[1]/h4/span"));
		String str = Status1.getText();

		log.info("Subscription is in Acive status:"+str+"");

		log.info("User validates active status on subscriptions details page");
		Thread.sleep(6000);
	}

	@And("^SMSD checks all the other fields start date end date and initial term are non editable$") 
	public void SMSD_checks_all_the_other_fields_start_date_end_date_and_initial_term_are_non_editable() throws InterruptedException {

			log.info("User checks all the other fields start date end date and initial term are non editable");
			Thread.sleep(3000);
	}

	@And("^SMSD user clicks on history tab and validates record exists$")
	public void SMSD_user_clicks_on_history_ab_and_validates_record_exists() throws InterruptedException {

		WebElement hist_tab_rec = driver.findElement(By.xpath("//div[2]/div/div/div[3]/div/ul/li[3]/a"));
		hist_tab_rec.click();

		WebElement records_exists = driver.findElement(By.xpath("//div[3]/div/div/div[1]/div/div/div[2]/div[3]/div[1]/table/tbody/tr[1]/td[1]/div"));
		String str = records_exists.getText();

		log.info("User clicks on history tab and validates record exists: "+str+"");
		Thread.sleep(6000);
	}

	@And("^SMSD user gets the subscription number and switches to parent window and validates status$")
	public void SMSD_user_gets_the_subsciprtion_number_and_closes_the_first_browser_for_view_details_page() throws InterruptedException {

		Thread.sleep(6000);

		WebElement sub_num = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/h4/span"));
		String sub_num1 = sub_num.getText();
		String sub_num2 = null;

		Pattern p = Pattern.compile("\\d+");
		Matcher m = p.matcher(sub_num1);
		while(m.find()) 
		{
			log.info(m.group());
			sub_num2 = m.group();
			log.info(sub_num2);
		}

		Thread.sleep(6000);

		Set<String> allWindowHandles = driver.getWindowHandles();
		for (@SuppressWarnings("unused") String handle : allWindowHandles) {
			driver.switchTo().window(allWindowHandles.iterator().next());
		}

		String url3 = driver.getCurrentUrl();
		log.info(url3);

		//enter subscription number
		WebElement enter_subnumber = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[1]/input"));
		enter_subnumber.clear();
		Thread.sleep(3000);
		enter_subnumber.sendKeys("sm03_subNum"); 	
		Thread.sleep(3000);
		
		//click on title
		WebElement title_text = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/h4"));
		title_text.click();
		Thread.sleep(3000);

		//click search
		WebElement search1_button = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[2]/div[2]/div/button[3]"));
		search1_button.click();
		Thread.sleep(3000);
		
		log.info("User gets the subscription number and switches to parent window and validates status");
		Thread.sleep(6000);
	}

	@Then("^SMSD user comes back to subscription details page and close the browser$")
	public void SMSD_user_comes_back_to_subscription_page_and_validates_the_record_is_in_active_status() throws InterruptedException {

		driver.switchTo().defaultContent();

		String parentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for (String childWindow : Allhandles) {

			driver.switchTo().window(childWindow);

			String url4 = driver.getCurrentUrl();
			log.info(url4);
		}

		driver.close();
		log.info("closing the subscription details tab successfully");

		driver.switchTo().window(parentWindow);
	}

	@And("^SMSD user clicks on user account dropdown$")
	public void SMSD_user_clicks_on_user_account_dropdown() throws InterruptedException {
		driver.switchTo().activeElement();

		Actions action = new Actions(driver);

		WebElement Drpdwn = driver.findElement(By.xpath("//*[@id=\"page-header-user-dropdown\"]"));
		action.moveToElement(Drpdwn).click().perform();

		log.info("User clicks on user account dropdown");
		Thread.sleep(3000);
	}

	@And("^SMSD user clicks on logout$")
	public void SMSD_user_clicks_on_logout() throws InterruptedException {
		Actions action = new Actions(driver);
		
		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();		
		
		log.info("logged out successfully");
		Thread.sleep(3000);
	}

	@And("^SMSD close the browser$")
	public void SMSD_close_the_browser() throws InterruptedException {
		driver.quit();
		
		log.info("close the final browser successfully");
		Thread.sleep(3000);
	}
}