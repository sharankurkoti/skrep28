import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SM15_Email_Notifications_StepDefinition extends TestBase {
	TestUtil testUtil;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public SM15_Email_Notifications_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	public String generateRandomString() {
		return "Sk_RenMod_Test" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	@Given("^user logs into application SMENO$")
	public void user_logs_into_application_SMENO() throws Exception 
	{	
		TestBase.initialization();	    

		Thread.sleep(8000);
		log.info("User logs into application successfully");	
	}

	@When("^title of the login page is Subscriptions SMENO$")
	public void title_of_login_page_is_Subscriptions_SMENO() 
	{
		String title = driver.getTitle();
		System.out.println();
		Assert.assertEquals("Dashboard", title);
		log.info("Title is validated successfully");
	}

	@Then("^user clicks on subscriptions link from left menu SMENO$")
	public void user_clicks_on_subscriptions_link_from_left_menu_SMENO() throws InterruptedException 
	{
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//ul/li/a[@href='#/subscriptions']"))).click().perform();

		Thread.sleep(3000);
		log.info("User clicks on subscriptions link successfully");
	}

	@And("^user is on Subscription page SMENO$")
	public void user_is_on_Subscription_page_SMENO() throws InterruptedException 
	{

		String title = driver.getTitle();
		System.out.println();
		Assert.assertEquals("Subscriptions", title);

		log.info("User is on Subscription page");
		Thread.sleep(6000);

	}

	@And("^user enters subscription number SMENO$")
	public void user_enters_subscription_number_SMENO() throws InterruptedException 
	{
		WebElement sub_num = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[1]/input"));
		sub_num.clear();
		sub_num.sendKeys(prop.getProperty("reg15_subNum"));

		log.info("User enters subscription number successfully");
		Thread.sleep(3000);
	}

	@And("^user clicks on search button SMENO$")
	public void user_clicks_on_search_button_SMENO() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();

		log.info("User clicks on search button");
		Thread.sleep(3000);
	}

	@And("^user clicks on hyperlink of the subscription number SMENO$")
	public void user_clicks_on_hyperlink_of_the_subscription_number_SMENO() throws InterruptedException {
		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[2]/div[1]/table/tbody/tr/td[2]/a"))).click().perform();

		Thread.sleep(3000);
		log.info("User clicks on hyperlink of the subscription number");
	}

	@And("^user clicks on view details link SMENO$")
	public void user_clicks_on_view_details_link_SMENO() throws InterruptedException {

		Thread.sleep(3000);
	}

	@And("^user navigates to subscription details page SMENO$") 
	public void user_navigates_to_subscription_details_page_SMENO() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String parentWindow = driver.getWindowHandle();
		Set<String> Allhandles = driver.getWindowHandles();
		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);
			String url = driver.getCurrentUrl();
			System.out.println(url);
			Thread.sleep(3000);
		}

		Thread.sleep(3000);
		log.info("User navigates to subscription details page");
	}

	@And("^user clicks on more actions button and selects send renewal notice SMENO$")
	public void user_clicks_on_more_actions_button_and_selects_send_renewal_notice_SMENO() throws InterruptedException {
		Actions action = new Actions(driver); 

		WebElement more_actions_btn = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
		more_actions_btn.click();
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Send Renewal Notice")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Send Renewal Notice")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		//close popup button
		Thread.sleep(5000);		
		log.info("User able to select send renewal notice option successfully");
	}

	@And("^user enters ToField CCField validates subject and clicks send button SMENO$")
	public void user_enters_ToField_CCField_validates_subject_and_clicks_send_button_SMENO() throws InterruptedException{
		Actions action = new Actions(driver);

		WebElement ToField = driver.findElement(By.xpath("//div[2]/form/div/div/div[1]/div[1]/div[2]/input"));
		ToField.clear();
		ToField.sendKeys(prop.getProperty("To_Field"));

		WebElement CCField = driver.findElement(By.xpath("//div[2]/form/div/div/div[1]/div[2]/div[2]/input"));
		CCField.clear();
		CCField.sendKeys(prop.getProperty("CC_Field"));

		WebElement email_body_text = driver.findElement(By.xpath("//div[2]/form/div/div/div[1]/div[4]/div[2]/textarea"));
		email_body_text.sendKeys("Test Email");

		//click on send button
		action.moveToElement(driver.findElement(By.xpath("//div[2]/div[1]/div/div/div/div/div[3]/button[1]"))).click().perform();

		Thread.sleep(5000);
		log.info("User validates email pop up body successfully");

	}

	@And ("^login to myorders shadow mail box and validate email SMENO$")
	public void login_to_myorders_shadow_mail_box_and_validate_email_SMENO() throws Exception {
        Actions action = new Actions(driver);
		
		TestBase.initialization1();
		Thread.sleep(5000);

		//provide login and password
		driver.findElement(By.xpath("//*[@id='i0116']")).sendKeys(prop.getProperty("username"));

		WebElement next_button = driver.findElement(By.xpath("//*[@id='idSIButton9']"));
		next_button.click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id='i0118']")).sendKeys(prop.getProperty("password"));

		WebElement signIn_button = driver.findElement(By.xpath("//*[@id='idSIButton9']"));
		signIn_button.click();
		Thread.sleep(8000);	

		//click on push button
		try {
			WebElement push_button = driver.findElement(By.xpath("//*[@id='auth_methods']/fieldset/div[1]/button"));
			push_button.click();
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			WebElement push_button = driver.findElement(By.xpath("//*[@id='auth_methods']/fieldset/div[1]/button"));
			push_button.click();
		}
		Thread.sleep(3000);	

		//click on Yes Button
		try {
			WebElement yes_button = driver.findElement(By.xpath("//*[@id='idSIButton9']"));
			yes_button.click();
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			WebElement yes_button = driver.findElement(By.xpath("//*[@id='idSIButton9']"));
			yes_button.click();
		}		
		Thread.sleep(3000);
		
		//open the email 
		action.moveToElement(driver.findElement(By.xpath("//div[2]/span[@title='myorders@presidio.com']"))).click().perform();
		Thread.sleep(3000);
		
		log.info("User logged into email and validated successfully");

	}
	
	@And("^user close the myorders mailbox page SMENO$")
	public void user_close_the_myorders_mailbox_page_SMENO() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();
		Set<String> allwindowhandles = driver.getWindowHandles();
		for(String currwindow : allwindowhandles) {
			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(3000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {
			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
		}
		log.info("User close the myorders mailbox page");
	}

	@And("^user close the subscriptions details page SMENO$") 
	public void user_close_the_subscription_details_page_SMENO() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(3000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);		
		}
		log.info("User close the subscriptions details page");
	}

	@And("^user clicks on logout SMENO$")
	public void user_clicks_on_logout_SMENO() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//*[@id='page-header-user-dropdown']"))).click().perform();
		Thread.sleep(3000);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();

		log.info("User clicks on logout");
	}

	@And("^close the browser SMENO$")
	public void close_the_browser_SMENO() {
		driver.quit();
		log.info("Close the browser");
	}
}