import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Reg14_Auto_Renewal_StepDefinition extends TestBase {
	TestUtil testUtil;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public Reg14_Auto_Renewal_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	public String generateRandomString() {
		return "Sk_RenMod_Test" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	@Given("^AR User logs into application$")
	public void AR_User_logs_into_application() throws Exception 
	{	
		TestBase.initialization();	    

		Thread.sleep(8000);
	}

	@When("^AR title of the login page is Subscriptions$")
	public void AR_title_of_login_page_is_Subscriptions() 
	{
		String title = driver.getTitle();
		log.info("Title of the login page is validated");
		Assert.assertEquals("Dashboard", title);
	}

	@Then("^AR User clicks on subscriptions link on left menu$")
	public void AR_User_clicks_on_subscriptions_link_on_left_menu() throws InterruptedException 
	{
		Actions action = new Actions(driver);		
		action.moveToElement(driver.findElement(By.xpath("//ul/li/a[@href='#/subscriptions']"))).click().perform();
		Thread.sleep(3000);
	}

	@And("^AR User is on Subscription page$")
	public void AR_User_is_on_Subscription_page() throws InterruptedException 
	{
		String title = driver.getTitle();
		Assert.assertEquals("Subscriptions", title);

		log.info("User is on Subscription page");
		Thread.sleep(6000);
	}

	@And("^AR User enters the subscription number$")
	public void AR_User_enters_the_subscription_number() throws InterruptedException 
	{		
		WebElement sub_num = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[1]/input"));
		sub_num.clear();
		sub_num.sendKeys(prop.getProperty("reg14_subNum"));

		log.info("User enters the subscription number");
		Thread.sleep(3000);
	}

	@And("^AR User clicks on search button$")
	public void AR_User_clicks_on_search_button() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();

		log.info("User clicks on search button");
		Thread.sleep(3000);
	}

	@And("^AR User clicks on hyperlink of the subscription number$")
	public void AR_User_clicks_on_hyperlink_of_the_subscription_number() throws InterruptedException {
		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[2]/div[1]/table/tbody/tr/td[2]/a"))).click().perform();
		Thread.sleep(3000);
		log.info("User clicks on hyperlink of the subscription number successfully");
	}

	@And("^AR User clicks on view details button$")
	public void AR_User_clicks_on_view_details_button() throws InterruptedException {

		Thread.sleep(3000);
		log.info("User clicks on view details button successfully");
	}


	@And("^AR User navigates to sub details page$") 
	public void AR_User_navigates_to_sub_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String pentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);
			String url = driver.getCurrentUrl();
			log.info(url);
			Thread.sleep(1000);
		}

		Thread.sleep(5000);
		log.info("User navigates to subscription detials page successfully");
	}

	@And("AR User clicks on related documents tab")
	public void AR_User_clicks_on_related_documents_tab() throws InterruptedException {
		Actions action = new Actions(driver); 

		action.moveToElement(driver.findElement(By.xpath("//li/a[@href='#RelatedDocuments']"))).click().perform();

		Thread.sleep(3000);
		log.info("User clicks on related documents tab successfully");
	}

	@And("AR User clicks on change request hyperlink")
	public void AR_User_clicks_on_change_request_hyperlink() throws InterruptedException {
		
        //scroll to top of the page
		JavascriptExecutor js77= (JavascriptExecutor) driver;
		js77.executeScript("window.scrollTo(0,document.body.scrollHeight)","");
		
		String Searchvalue = "Renewal Automatic";

		//get name and details link element.		
		List<WebElement> typevalue = driver.findElements(By.xpath("//*[@id=\"second\"]/div[3]/div[1]/table/tbody/tr/td[3]"));
		List<WebElement> link = driver.findElements(By.xpath("//tbody/tr/td/a[@class]"));
		
		int typevalue_count = typevalue.size();
		int link_count = link.size();
		
		log.info("No. of Rows in the Table:" +typevalue_count);
		log.info("No. of links in the Table:" +link_count);
		
		for (int i =0; i<typevalue_count;i++) {

		    String actualtype = typevalue.get(i).getText();
		    System.out.println("Type Values : "+typevalue);

		    if (actualtype.equalsIgnoreCase(Searchvalue)) {
		        log.info("Found the value");
		        link.get(i).click();
		        break;
		    }
		}
		
		Thread.sleep(3000);
		log.info("User clicks on change request hyperlink successfully");
	}

	@And("^AR User navigates to change request page$") 
	public void AR_User_navigates_to_change_request_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		//String pentWindow = driver.getWindowHandle();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);
			String url = driver.getCurrentUrl();
			log.info(url);
			Thread.sleep(1000);
		}

		Thread.sleep(3000);
		log.info("User navigates to change request page successfully");
	}

	@And("^AR User validates automatic renewal message$")
	public void AR_User_validates_automatic_renewal_message() throws InterruptedException {

		WebElement Auto_Renew_Msg = driver.findElement(By.xpath("//*[@id=\"layout-wrapper\"]/div[2]/div/div/div[3]/span[1]/strong"));
		String str1 = Auto_Renew_Msg.getText();

		log.info(str1);

		Thread.sleep(3000);
		log.info("User validates automatic renewal message successfully");
	}

	@And("^AR User validates change type value$")
	public void AR_User_validates_change_type_value() throws InterruptedException {
		Actions action = new Actions(driver);
		
		action.moveToElement(driver.findElement(By.xpath("//li/a[@href='#Information']"))).click().perform();
		Thread.sleep(3000);
		
		WebElement select = driver.findElement(By.xpath("//*[@id=\"Informationdiv\"]/div/div[1]/div[3]/div[2]"));
		String str1  = select.getText();
		
		log.info("first selected value is ("+str1+")");
		
		//Assert.assertEquals("Renewal Automatic",str1);
		Thread.sleep(3000);
		log.info("User validates change type value successfully");
	}

	@And("^AR User close the change request details page$")
	public void AR_User_close_the_change_request_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(3000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
		}
		log.info("User close the change request details page successfully");
	}

	@And("^AR User close the subscriptions details page$") 
	public void AR_User_close_the_subscription_details_page() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(2000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);

			log.info("User close the subscriptions details page successfully");
		}

	}

	@And("^AR User clicks on logout$")
	public void AR_User_clicks_on_logout() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//*[@id='page-header-user-dropdown']"))).click().perform();
		Thread.sleep(5000);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();

		log.info("User clicks on logout successfully");
	}

	@And("^AR close the browser$")
	public void AR_close_the_browser() {
		driver.quit();
		log.info("Close the browser successfully");
	}
}