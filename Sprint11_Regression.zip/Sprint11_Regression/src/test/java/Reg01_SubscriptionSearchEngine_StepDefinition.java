import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Reg01_SubscriptionSearchEngine_StepDefinition extends TestBase {
	
	TestUtil testUtil;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public Reg01_SubscriptionSearchEngine_StepDefinition() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	public void setUp() throws Exception 
	{
		initialization();		
	}

	@Given("^SEngine user is already on subscriptions page$")
	public void SEngine_user_is_already_on_subscriptions_page() throws Exception 
	{	
	
	    TestBase.initialization();	    
		Thread.sleep(8000);
	}

	@Given("^SEngine title of the login page is Subscriptions$")
	public void SEngine_title_of_login_page_is_Subscriptions() 
	{
		String title = driver.getTitle();
		log.info(title);
		Assert.assertEquals("Dashboard", title);
        
		log.info("User able to validate title successfully");
	}

	@And("^SEngine user clicks on view details link$")
	public void SEngine_user_clicks_on_view_details_link() throws InterruptedException 
	{
		driver.findElement(By.xpath("//a[@class='order-link']/a[@href='#/subscriptions?status=1']")).click();
		Thread.sleep(3000);
	}

	@And("^SEngine user is on Subscription page$")
	public void SEngine_user_is_on_Subscription_page() throws InterruptedException 
	{

		String title = driver.getTitle();
		log.info(title);
		Assert.assertEquals("Subscriptions", title);
		Thread.sleep(6000);

	}

	@And("^SEngine user clicks on first time add button$")
	public void SEngine_user_clicks_on_first_time_add_button() throws InterruptedException
	{
		WebElement Add_button = driver.findElement(By.xpath("//div/i[@title='Add']"));
		Add_button.click();
		Thread.sleep(3000);

	}

	@And("^SEngine user clicks on first subscription dropdown selects dropdown value$")
	public void SEngine_user_clicks_on_subscription_dropdown_selects_dropdown_value() throws InterruptedException 
	{

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[1]/div[1]/div[1]/select"))).perform();
		WebElement Drpdwn = driver.findElement(By.xpath("//div[1]/div[1]/div[1]/select"));
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[1]/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("True Forward");
	}

	@And("^SEngine user clicks on first dropdown and selects option$")
	public void SEngine_user_clicks_on_first_dropdown_and_selects_option() {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div/div[1]/select"))).perform();
		WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div/div[1]/select"));
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Yes");
	}

	@And("^SEngine user clicks on second time add button$")
	public void SEngine_user_clicks_on_second_time_add_button() throws InterruptedException
	{
		WebElement Add_button = driver.findElement(By.xpath("//div/i[@title='Add']"));
		Add_button.click();
		Thread.sleep(3000);

	}

	@And("^SEngine user clicks on second subscription dropdown selects dropdown value$")
	public void SEngine_user_clicks_on_second_subscription_dropdown_selects_dropdown_value() throws InterruptedException 
	{

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[1]/select"))).perform();
		WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[1]/select"));
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[2]/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Pending Cancellation");
		Thread.sleep(3000);
	}

	@And("^SEngine user clicks on second dropdown and selects option$")
	public void SEngine_user_clicks_on_second_dropdown_and_selects_option() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div/div[1]/select"))).perform();
		WebElement Drpdwn = driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div/div[1]/select"));
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("No");
		Thread.sleep(3000);
	}

	@And("^SEngine user clicks on search button$")
	public void SEngine_user_clicks_on_search_button() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();
		Thread.sleep(3000);
	}

	@And ("^SEngine user clicks on save search button$")
	public void SEngine_user_clicks_on_save_search_button() throws InterruptedException {
		WebElement save_button = driver.findElement(By.xpath("//div/button[contains(text(),'Save')]"));
		save_button.click();
		Thread.sleep(3000);

	}

	@And ("^SEngine user verifies message User Search Setting Saved$")
	public void SEngine_user_verifies_message_User_Search_Setting_Saved() throws InterruptedException {	

		WebElement title = driver.findElement(By.xpath("//span[contains(text(),'User Search Setting Saved')]"));
		String title1 = title.getText();
		log.info(title1);
		Assert.assertEquals("User Search Setting Saved", title1);
		Thread.sleep(3000);
	}	

	@And("^SEngine user unable to click on send renewal notice button$")
	public void SEngine_user_unable_to_click_on_send_renewal_notice_button()throws InterruptedException{
		WebElement srn_button = driver.findElement(By.xpath("//*[@id=\"datatable_wrapper\"]/div[1]/div[3]/div/button[1]"));
		srn_button.click();
		Thread.sleep(3000);
	}


	@And("^SEngine user clicks on third time subscription dropdown selects dropdown value$")
	public void SEngine_user_clicks_on_third_time_subscription_dropdown_selects_dropdown_value() throws InterruptedException 
	{

		Actions action = new Actions(driver);
		WebElement Drpdwn = driver.findElement(By.xpath("//div[4]/div[1]/div/div/div[1]/div/div[1]/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[4]/div[1]/div/div/div[1]/div/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Status");
		Thread.sleep(6000);
	}

	@And("^SEngine user clicks on third time dropdown and selects option$")
	public void SEngine_user_clicks_on_third_time_dropdown_and_selects_option() throws InterruptedException {
		Actions action = new Actions(driver);

		WebElement Drpdwn = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
		action.moveToElement(Drpdwn).click().perform();
		
		try {
			List<WebElement> options = driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Active")) {
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options = driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Active")) {
					option.click();
				}
			}
		}	

		Thread.sleep(8000);

		WebElement Drpdwn1 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
		Drpdwn1.click();
				
		try {
			WebElement selected_option = driver.findElement(By.xpath("//div/ul/li[1]/span/span[contains(text(),'New')]"));
			selected_option.click();
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			WebElement selected_option = driver.findElement(By.xpath("//div/ul/li[1]/span/span[contains(text(),'New')]"));
			selected_option.click();
		}	
		Thread.sleep(3000);
	}

	@And("^SEngine user clicks on search button second time$")
	public void SEngine_user_clicks_on_search_button_second_time() throws InterruptedException {
        Actions action = new Actions(driver);	
        
		WebElement search_button2 = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		action.moveToElement(search_button2);
		search_button2.click();
		Thread.sleep(3000);
	}

	@And("^SEngine user clicks on checkbox$")
	public void SEngine_user_clicks_on_checkbox()throws InterruptedException{
		Actions action = new Actions(driver);
		
		WebElement Drpdwn = driver.findElement(By.xpath("//div[4]/div[1]/div/div/div[1]/div/div[1]/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[4]/div[1]/div/div/div[1]/div/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Subs #");
		
		Thread.sleep(5000);
		
		WebElement sub_num = driver.findElement(By.xpath("//div[4]/div[1]/div/div/div[1]/div/div[1]/div[2]/div/div[1]/input"));
		sub_num.clear();
		sub_num.sendKeys(prop.getProperty("reg01_subNum"));
		
		WebElement search_button2 = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		action.moveToElement(search_button2);
		search_button2.click();
		Thread.sleep(3000);

		Thread.sleep(3000);
		WebElement check_box = driver.findElement(By.xpath("//tbody/tr[1]/td/input[@type='checkbox']"));
		check_box.click();
		Thread.sleep(3000);
	}

	@And("^SEngine user able to click on send renewal notice button$")
	public void SEngine_user_able_to_click_on_send_renewal_notice_button()throws InterruptedException{
		WebElement srn_button = driver.findElement(By.xpath("//*[@id=\"datatable_wrapper\"]/div[1]/div[3]/div/button[1]"));
		srn_button.click();
		Thread.sleep(3000);	
	}

	@And("^SEngine user able to click on x to close the popup message$")
	public void SEngine_user_able_to_click_on_x_to_close_the_popup_message()throws InterruptedException{

		Thread.sleep(3000);
	}

	@Then("^SEngine user able to click on export button and file gets downloaded$")
	public void SEngine_user_able_to_click_on_export_button_and_file_gets_downloaded() throws InterruptedException{

		Actions action = new Actions(driver);
		try {
			WebElement export_button = driver.findElement(By.xpath("//button[contains(text(),'Export')]"));
			action.doubleClick(export_button).perform();
		}
		
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			WebElement export_button = driver.findElement(By.xpath("//button[contains(text(),'Export')]"));
			action.doubleClick(export_button).perform();
		}

		Thread.sleep(10000);	
	}


	@And("^SEngine user able to click on column options first time$")
	public void SEngine_user_able_to_click_on_column_options_first_time() throws InterruptedException {
		WebElement co_button = driver.findElement(By.xpath("//div//button[contains(text(),'Column Options')]"));
		co_button.click();
		Thread.sleep(3000);	

	}
	@And("^SEngine user selects available options and clicks add$")
	public void SEngine_user_selects_available_options_and_clicks_add() throws InterruptedException {
		driver.switchTo().activeElement();
		WebElement co_button = driver.findElement(By.xpath("//div[1]/select[1]/option[1]"));
		co_button.click();
		Thread.sleep(3000);	
	}

	@And("^SEngine user clicks on apply button first time$")
	public void SEngine_user_clicks_on_apply_button_first_time() throws InterruptedException{

		WebElement apply_button = driver.findElement(By.xpath("//div/button[contains(text(),\"Apply\")]"));
		apply_button.click();
		Thread.sleep(3000);

	}
	@And("^SEngine user able to click on column options second time$")
	public void SEngine_user_able_to_click_on_column_options_second_time() throws InterruptedException {
		WebElement co_button = driver.findElement(By.xpath("//div//button[contains(text(),'Column Options')]"));
		co_button.click();
		Thread.sleep(3000);	


	}
	@And("^SEngine user selects already selection options and clicks on remove button$")
	public void SEngine_user_selects_already_selection_options_and_clicks_on_remove_button() throws InterruptedException{
		driver.switchTo().activeElement();
		WebElement co_button = driver.findElement(By.xpath("//div[1]/select[1]/option[1]"));
		co_button.click();
		co_button.click();
		Thread.sleep(3000);	
	}

	@And("^SEngine user clicks on apply button second time$")
	public void SEngine_user_clicks_on_apply_button_second_time() throws InterruptedException {
		WebElement apply_button = driver.findElement(By.xpath("//div/button[contains(text(),'Apply')]"));
		apply_button.click();
		Thread.sleep(3000);
	}

	@And("^SEngine user able to click on column options third time$")
	public void SEngine_user_able_to_click_on_column_options_third_time() throws InterruptedException {
		WebElement co_button = driver.findElement(By.xpath("//div//button[contains(text(),'Column Options')]"));
		co_button.click();
		Thread.sleep(3000);	
	}

	@Then("^SEngine user clicks on cancel button$")
	public void SEngine_user_clicks_on_cancel_button() throws InterruptedException {
		WebElement cancel_button = driver.findElement(By.xpath("//div/button[contains(text(),'Cancel')]"));
		cancel_button.click();
		Thread.sleep(3000);
	}

	@And("^SEngine user clicks on reset button on the search menu$")
	public void SEngine_user_clicks_on_reset_button_on_the_search_menu() throws InterruptedException {
		WebElement reset_button = driver.findElement(By.xpath("//div/a[@href='javascript:void(0)'][@class='link-color']"));
		reset_button.click();
		Thread.sleep(3000);
	}

	@And("^SEngine user unable to click the checkbox for cancelled status$")
	public void SEngine_user_unable_to_click_the_checkbox_for_cancelled_status() throws InterruptedException {
		Actions action = new Actions(driver);

		//Search for cancelled subscriptions
		
		WebElement Drpdwn = driver.findElement(By.xpath("//div[4]/div[1]/div/div/div[1]/div[1]/div[1]/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[4]/div[1]/div/div/div[1]/div[1]/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Status");

		
		WebElement Drpdwn1 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
		action.moveToElement(Drpdwn1).click().perform();
		
		try {
			List<WebElement> options = driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Canceled")) {
					option.click();
				}
			}
		}
		
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options = driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));
			for(WebElement option : options) {
				if(option.getText().trim().contains("Canceled")) {
					option.click();
				}
			}
		}
		
		Thread.sleep(8000);
		
         //click	
		WebElement title_subs = driver.findElement(By.xpath("//div[2]/div/div/div[3]/div/div/h4"));
		title_subs.click();
		Thread.sleep(3000);
		
		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();
		Thread.sleep(3000);
		
		WebElement checkbox_clk = driver.findElement(By.xpath("//div[2]/div[1]/table/tbody/tr[1]/td[1]"));
		checkbox_clk.click();
		Thread.sleep(3000);
		
		log.info("unable to click the checkbox");
	}

	@And("^SEngine user able to filter entries display on page$")
	public void SEngine_user_able_to_filter_entries_display_on_page() throws InterruptedException {
		
		WebElement reset_button = driver.findElement(By.xpath("//div/a[@href='javascript:void(0)'][@class='link-color']"));
		reset_button.click();
		Thread.sleep(3000);

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//div/label/select[@name='datatable_length']"))).perform();
		WebElement Drpdwn7 = driver.findElement(By.xpath("//div/label/select[@name='datatable_length']"));
		Drpdwn7.click();

		Select Drp_entries = new Select(driver.findElement(By.xpath("//div/label/select[@name='datatable_length']")));		
		Drp_entries.selectByVisibleText("50");

		Thread.sleep(3000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollTo(0,document.body.scrollHeight)","");

		Thread.sleep(3000);

	}

	@And("^SEngine user able to navigate to next page to check records$")
	public void SEngine_user_able_to_navigate_to_next_page_to_check_records() throws InterruptedException {

		try {
			WebElement next_page1 = driver.findElement(By.xpath("//div/ul/li[2]/a[@class='page-link']"));
			next_page1.click();
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			WebElement next_page1 = driver.findElement(By.xpath("//div/ul/li[2]/a[@class='page-link']"));
			next_page1.click();
		}

		Thread.sleep(3000);
	}


	@And("^SEngine user clicks on user account dropdown$")
	public void SEngine_user_clicks_on_user_account_dropdown() throws InterruptedException {

		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//*[@id=\"page-header-user-dropdown\"]"))).click().perform();
		Thread.sleep(3000);
	}

	@And("^SEngine user clicks on logout$")
	public void SEngine_user_clicks_on_logout() {
		Actions action = new Actions(driver);
		
		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();	
	}

	@And("^SEngine close the browser$")
	public void SEngine_close_the_browser() {
		driver.quit();
	}

}