import java.io.File;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import com.sprint.qa.base.TestBase;
import com.sprint.qa.helper.LoggerHelper;
import com.sprint.qa.util.TestUtil;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Reg13_Initiate_Renewal_ModifyDetails_StepDefinition extends TestBase {
	TestUtil testUtil;
	public static String date1;
	Logger log = LoggerHelper.getLogger(LoggerHelper.class);

	public Reg13_Initiate_Renewal_ModifyDetails_StepDefinition() 
	{
		super(); // super class constructor to initialize properties
	}

	public void setUp() throws Exception 
	{
		initialization();		
	}

	public String generateRandomString() {
		return "Sk_RenMod_Test" + new BigInteger(30, new SecureRandom()).toString(32);
	}

	@Given("^user logs into application IRM$")
	public void user_logs_into_application_IRM() throws Exception 
	{	
		TestBase.initialization();	    

		Thread.sleep(8000);
	}

	@Then("^title of the login page is Subscriptions IRM$")
	public void title_of_login_page_is_Subscriptions_IRM() 
	{
		String title = driver.getTitle();
		log.info("Title page is validated");
		Assert.assertEquals("Dashboard", title);
	}

	@And("^user clicks on view details link IRM$")
	public void user_clicks_on_view_details_link_IRM() 
	{
		driver.findElement(By.xpath("//a[@class='order-link']/a[@href='#/subscriptions?status=1']")).click();
	}

	@And("^user is on Subscription page IRM$")
	public void user_is_on_Subscription_page_IRM() throws InterruptedException 
	{

		String title = driver.getTitle();
		Assert.assertEquals("Subscriptions", title);
		
		log.info("User is on Subscription page");
		Thread.sleep(6000);

	}

	@And("^user clicks on subscription dropdown selects dropdown value IRM$")
	public void user_clicks_on_subscription_dropdown_selects_dropdown_value_IRM() throws InterruptedException 
	{
		Actions action = new Actions(driver);

		WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div/div[1]/div[1]/select"));
		action.moveToElement(Drpdwn).click().perform();
		Drpdwn.click();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div/div[1]/div[1]/select")));		
		DrpdwnAnyOption.selectByVisibleText("Subs #");

		Thread.sleep(5000);

		WebElement sub_num = driver.findElement(By.xpath("//div[3]/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div/div[1]/input"));
		sub_num.clear();
		sub_num.sendKeys(prop.getProperty("reg13_subNum"));

		log.info("User clicks on subscription dropdown selects dropdown value");
		Thread.sleep(3000);
	}

	@And("^user clicks on second dropdown and select status active IRM$")
	public void user_clicks_on_second_dropdown_and_select_status_active_IRM() throws InterruptedException {

		Thread.sleep(3000);
	}

	@And("^user clicks on search button IRM$")
	public void user_clicks_on_search_button_IRM() throws InterruptedException {

		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();
		
		log.info("User clicks on search button");
		Thread.sleep(3000);
	}

	@And("^user navigates to actions column and click on dots and selects an option IRM$")
	public void user_navigates_to_actions_column_and_click_on_dots_and_selects_an_option_IRM() throws InterruptedException {
		Actions action = new Actions(driver);

		WebElement head_title = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/h4"));
		head_title.click();
		Thread.sleep(3000);

		action.moveToElement(driver.findElement(By.xpath("//*[@id='dropdownMenuButton']"))).click().perform();
		Thread.sleep(3000);

		List<WebElement> options =    driver.findElements(By.cssSelector("a[href='javascript:void(0)'][class='dropdown-item']"));
		for(WebElement option : options) {
			if(option.getText().trim().contains("Initiate Renewal")) {
				option.click();
			}
		}
		Thread.sleep(3000);
		log.info("User navigates to actions column and click on dots and selects an option");
	}

	@And("^user select renew modify from popup window IRM$")
	public void user_select_renew_modify_from_popup_window_IRM() throws InterruptedException {
		driver.switchTo().activeElement();
		Actions action = new Actions(driver);

		try
		{
			WebElement radio_button = driver.findElement(By.xpath("//div/label[@for='RenewModify'][@class='custom-control-label']"));
			action.click(radio_button).click().perform();
		}
		catch(Exception e)
		{
			WebElement Drpdwn = driver.findElement(By.xpath("//div[3]/div/div[1]/div[1]/div[1]/div[1]/select"));
			action.moveToElement(Drpdwn).click().perform();
			Drpdwn.click();

			Thread.sleep(3000);

			Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[3]/div/div[1]/div[1]/div[1]/div[1]/select")));		
			DrpdwnAnyOption.selectByVisibleText("Status");
			Thread.sleep(3000);

			WebElement Drpdwn1 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
			action.moveToElement(Drpdwn1).click().perform();

			List<WebElement> options = driver.findElements(By.xpath("//div/ul/li/span[@class='multiselect__option']"));

			for(WebElement option : options) {
				if(option.getText().trim().contains("Active")) {
					option.click();
				}
			}
			Thread.sleep(8000);

			WebElement Drpdwn2 = driver.findElement(By.xpath("//div[@class='multiselect__select']"));
			action.moveToElement(Drpdwn2).click().perform();

			WebElement selected_option = driver.findElement(By.xpath("//div[2]/div/div[1]/div/div[3]/ul/li[1]/span"));
			action.click(selected_option).perform();
			Thread.sleep(3000);

			WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
			search_button.click();
			Thread.sleep(3000);

			WebElement sort_desc = driver.findElement(By.xpath("//div[2]/div[1]/table/thead/tr/th[5]/div[2]/span/i"));
			action.click(sort_desc).perform();
			Thread.sleep(3000);

			action.moveToElement(driver.findElement(By.xpath("//*[@id='dropdownMenuButton']"))).build().perform();
			WebElement dots = driver.findElement(By.xpath("//*[@id='dropdownMenuButton']"));
			dots.click();

			List<WebElement> options1 =    driver.findElements(By.cssSelector("a[href='javascript:void(0)'][class='dropdown-item']"));
			for(WebElement option : options1) {
				if(option.getText().trim().contains("Initiate Renewal")) {
					option.click();
				}
			}
			Thread.sleep(3000);

			//try to find the radio button once again
			WebElement radio_button = driver.findElement(By.xpath("//div/label[@for='RenewModify'][@class='custom-control-label']"));
			action.click(radio_button).click().perform();
		}
		Thread.sleep(3000);

		WebElement ok_button = driver.findElement(By.xpath("//div/button[contains(text(),'Ok')]"));
		ok_button.click();
		
		Thread.sleep(3000);
		log.info("User select renew modify from popup window");
	}

	@And("^user navigates to change request page IRM$") 
	public void user_navigates_to_change_request_page_IRM() throws InterruptedException {
		driver.switchTo().defaultContent();

		Set<String> Allhandles = driver.getWindowHandles();

		for( String childWindow1 : Allhandles) {

			driver.switchTo().window(childWindow1);
			String url = driver.getCurrentUrl();
			log.info(url);
			Thread.sleep(3000);
		}

		Thread.sleep(3000);
		log.info("User navigates to change request page");
	}

	@And("update fields on cr page and validate with audit trail values of history tab IRM")
	public void update_fields_on_cr_page_and_validate_audit_trail_Values_of_history_tab_IRM() throws InterruptedException {
		Actions action = new Actions(driver); 
		Thread.sleep(3000);

		WebElement title1 = driver.findElement(By.xpath("//div[@id='titleDiv']/input[@class='form-control']"));
		title1.sendKeys(generateRandomString());
		@SuppressWarnings("unused")
		String title2 = title1.getText();  
		Thread.sleep(3000);

		WebElement save_button1 = driver.findElement(By.xpath("//div[@id='Subscription']/div/div[1]/div/div[2]/div/button[1]"));
		action.moveToElement(save_button1).click().perform();
		Thread.sleep(3000);

		//scroll down
		JavascriptExecutor js2 = (JavascriptExecutor)driver;
		js2.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(5000);

		WebElement qty_edit = driver.findElement(By.xpath("//div[3]/div[1]/div/table/tbody/tr[1]/td[8]/div/input"));
		action.moveToElement(qty_edit).sendKeys("140");
		Thread.sleep(3000);

		WebElement ulp_edit = driver.findElement(By.xpath("//div[3]/div[1]/div/table/tbody/tr[1]/td[9]/span/input"));
		action.moveToElement(ulp_edit).sendKeys("10");
		Thread.sleep(3000);

		//pofund:
		//start date:
		//Title
		//business development manager

		JavascriptExecutor js22 = (JavascriptExecutor)driver;
		js22.executeScript("window.scrollBy(0,-400)", "");

		//update previous date to start date
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		log.info("Today's date is "+dateFormat.format(cal.getTime()));
		cal.add(Calendar.DATE, -1);
		log.info("Yesterday's date was "+dateFormat.format(cal.getTime())); 

		String date12 = dateFormat.format(cal.getTime()); 
		
		date1 = date12;

		WebElement str_date = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[2]/div[1]/div[2]/div/div/input"));
		str_date.sendKeys(date1);
		Thread.sleep(3000);

		WebElement title3 = driver.findElement(By.xpath("//div[@id='titleDiv']/input[@class='form-control']"));
		title3.clear();
		title3.sendKeys(generateRandomString());
		@SuppressWarnings("unused")
		String title4 = title3.getText();  
		Thread.sleep(3000);

		//toggle switch
		Thread.sleep(3000);

		//scroll down
		JavascriptExecutor js3 = (JavascriptExecutor)driver;
		js3.executeScript("window.scrollBy(0,700)", "");

		Thread.sleep(3000);

		WebElement toggle_btn = driver.findElement(By.xpath("//*[@id='table-vertical-scroll']/div[2]/div[2]/ul/li[3]/i"));
		action.moveToElement(toggle_btn).click().perform();

		Thread.sleep(3000);

		action.moveToElement(toggle_btn).click().perform();
		Thread.sleep(8000);
		
		//navigate to change order details tab
		WebElement cod_tab2 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Information']"));
		action.moveToElement(cod_tab2).click().perform();
			
		//update change order info
		WebElement bill_to1 = driver.findElement(By.xpath("//*[@id=\"Informationdiv\"]/div/div[2]/div[1]/div[2]/select"));
		action.moveToElement(bill_to1).click().perform();
		Thread.sleep(3000);
		
		Select drp_dwn_anyoption1 = new Select(driver.findElement(By.xpath("//*[@id=\"Informationdiv\"]/div/div[2]/div[1]/div[2]/select")));
        drp_dwn_anyoption1.selectByIndex(1);
        Thread.sleep(3000);
		
        //update purchase order info
		WebElement bill_to2 = driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[2]/div[1]/div[2]/select"));
		action.moveToElement(bill_to2).click().perform();
		Thread.sleep(3000);
		
		Select drp_dwn_anyoption2 = new Select(driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[2]/div[1]/div[2]/select")));
        drp_dwn_anyoption2.selectByIndex(0);
        Thread.sleep(3000);
        
       // provide email id
        WebElement vend_title= driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[1]/div[1]/div[2]/label"));
        action.moveToElement(vend_title).click().perform();
        Thread.sleep(3000);
        
        WebElement email_id = driver.findElement(By.xpath("//*[@id=\"PurchaseOrderInformationDiv\"]/div/div[2]/div[2]/div[2]/input"));
        email_id.sendKeys(prop.getProperty("email_idd"));        
		Thread.sleep(5000);
		
		WebElement save_button2 = driver.findElement(By.xpath("//div/div/div[2]/div/div[2]/div/button[1]"));
		action.moveToElement(save_button2).click().perform();
		Thread.sleep(3000);
        
		//upload file
		Thread.sleep(3000);

		JavascriptExecutor js4 = (JavascriptExecutor)driver;
		js4.executeScript("window.scrollBy(0,450)", "");

		Thread.sleep(3000);

		WebElement upload_btn = driver.findElement(By.xpath("//button[contains(text(),'Upload')][@class='btn btn-md btn-primary btn-sm']"));
		action.moveToElement(upload_btn).click().perform();

		Thread.sleep(3000);

		driver.switchTo().activeElement();

		try 
		{

			WebElement browse = driver.findElement(By.xpath("//form/div/input"));
			File file1 = new File("C:\\Selenium\\SubscriptionList.xls");
			browse.sendKeys(file1.getAbsolutePath());

		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{

			WebElement browse = driver.findElement(By.xpath("//form/div/input"));
			File file1 = new File("C:\\Selenium\\SubscriptionList.xls");
			browse.sendKeys(file1.getAbsolutePath());

		}

		log.info("xls file uploaded successfully"); 

		Thread.sleep(3000);

		WebElement attachment_name1 = driver.findElement(By.xpath("//div[2]/div/div[1]/div/div[2]/div/div[1]/input"));
		attachment_name1.sendKeys(generateRandomString());

		Thread.sleep(3000);

		WebElement drop_downf = driver.findElement(By.xpath("//div[2]/div/div/div/div/div/div[2]/div/div[2]/div/div[2]/select"));
		action.click(drop_downf).build().perform();

		Thread.sleep(3000);
		Select dropdownvalue = new Select(driver.findElement(By.xpath("//div[2]/div/div/div/div/div/div[2]/div/div[2]/div/div[2]/select")));
		dropdownvalue.selectByIndex(6);

		Thread.sleep(3000);
		WebElement attachclose_btn= driver.findElement(By.xpath("//div[2]/div/div/div/div/div[3]/button[2]"));
		attachclose_btn.click();

		Thread.sleep(5000);

		//Upload file without internal option

		WebElement upload_btn1 = driver.findElement(By.xpath("//button[contains(text(),'Upload')][@class='btn btn-md btn-primary btn-sm']"));
		action.moveToElement(upload_btn1).click().perform();

		Thread.sleep(3000);

		driver.switchTo().activeElement();

		try 
		{
			WebElement browse1 = driver.findElement(By.xpath("//form/div/input"));
			File file2 = new File("C:\\Selenium\\Order.pdf");
			browse1.sendKeys(file2.getAbsolutePath());
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			WebElement browse1 = driver.findElement(By.xpath("//form/div/input"));
			File file2 = new File("C:\\Selenium\\Order.pdf");
			browse1.sendKeys(file2.getAbsolutePath());
		}

		log.info("pdf file uploaded successfully"); 
		//click on ‘Choose file’ to upload the desired file

		Thread.sleep(3000);

		WebElement attachment_name2 = driver.findElement(By.xpath("//div[2]/div/div[1]/div/div[2]/div/div[1]/input"));
		attachment_name2.sendKeys(generateRandomString());

		Thread.sleep(3000);

		//uncheck check box
		WebElement internal_checkbox = driver.findElement(By.xpath("//div[@class='custom-control custom-checkbox']"));
		internal_checkbox.click();

		WebElement drop_downf1 = driver.findElement(By.xpath("//div[2]/div/div/div/div/div/div[2]/div/div[2]/div/div[2]/select"));
		action.click(drop_downf1).build().perform();

		Thread.sleep(3000);
		Select dropdownvalue1 = new Select(driver.findElement(By.xpath("//div[2]/div/div/div/div/div/div[2]/div/div[2]/div/div[2]/select")));
		dropdownvalue1.selectByIndex(6);

		Thread.sleep(3000);
		WebElement attachclose_btn1= driver.findElement(By.xpath("//div[2]/div/div/div/div/div[3]/button[2]"));
		attachclose_btn1.click();

		Thread.sleep(5000);

		//delete the file 		
		WebElement delete_attachedfile = driver.findElement(By.xpath("//*[@id='attachementdiv']/div[1]/div/ul/li/a[2]/i"));
		delete_attachedfile.click();

		WebElement ok_button = driver.findElement(By.xpath("//div[5]/div/div/div/div[1]/div/div/div/div/div[3]/button[1]"));
		ok_button.click();

		Thread.sleep(5000);

		//Select commission & Contributors
		//drag the cursor
		WebElement crd_tab2 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Subscription']"));
		action.moveToElement(crd_tab2).click().perform();

		Thread.sleep(5000);

		WebElement cod_tab3 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Information']"));
		action.moveToElement(cod_tab3).click().perform();

		Thread.sleep(5000);

		JavascriptExecutor js5 = (JavascriptExecutor) driver;
		js5.executeScript("window.scrollBy(0,700)", "");

		Thread.sleep(5000);

		//click on edit button
		WebElement edit_btn = driver.findElement(By.xpath("//*[@id=\"col2\"]/div/div/div[7]/button"));
		action.moveToElement(edit_btn).click().perform();
		
		//select role
		driver.switchTo().activeElement();
		WebElement role_dropdown = driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div/div[2]/select"));
		action.moveToElement(role_dropdown).click().perform();

		Select DrpdwnAnyOption = new Select(driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div/div[2]/select")));		
		DrpdwnAnyOption.selectByIndex(5);

		Thread.sleep(10000);

		//select commission recipient
		//add first comm agent

		WebElement comm1= driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div/div[4]/div/input"));
		action.moveToElement(comm1).click().perform();
		comm1.clear();
		comm1.sendKeys("Chad");

		Thread.sleep(1000);

		WebElement icon_search = driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div/div[4]/div/i"));
		action.moveToElement(icon_search).click().perform();

		Thread.sleep(2000);

		List<WebElement> options1 = driver.findElements(By.xpath("//*[@id=\"autocomplete-results\"]"));

		Thread.sleep(2000);

		for(WebElement option : options1) {
			if(option.getText().trim().contains("Chad Engel")){
				option.click();
			}

		}

		Thread.sleep(5000);

		WebElement add_button1 = driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[2]/button/i"));
		add_button1.click();	

		Thread.sleep(8000);

		log.info("first commission agent added successfully"); 

		WebElement comm2= driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div/div[4]/div/input"));
		action.moveToElement(comm2).click().perform();
		comm2.clear();
		comm2.sendKeys("Sha");

		Thread.sleep(2000);

		WebElement icon_search1 = driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div/div[4]/div/i"));
		action.moveToElement(icon_search1).click().perform();

		Thread.sleep(1000);

		List<WebElement> options2 = driver.findElements(By.xpath("//*[@id=\"autocomplete-results\"]"));

		Thread.sleep(2000);

		for(WebElement option : options2) {
			if(option.getText().trim().contains("Shane Orr")){
				option.click();
			}

		}

		Thread.sleep(5000);
		WebElement add_button2 = driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[2]/button/i"));
		add_button2.click();	
		Thread.sleep(3000);
		
		log.info("second commission agent added successfully"); 

		WebElement text_field2 = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/table/tbody/tr[1]/td[2]/input"));
		text_field2.clear();
		text_field2.sendKeys("30");
		Thread.sleep(5000);

		WebElement text_field1 = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/table/tbody/tr[2]/td[2]/input"));
		text_field1.clear();
		text_field1.sendKeys("70");
		Thread.sleep(3000);

		//click on save button
		WebElement save_button3 = driver.findElement(By.xpath("//div[7]/div/div/div/div/div/div[3]/button[2]"));
		save_button3.click();
		Thread.sleep(6000);

		//add notes
		//click on notes button
		//drag the cursor

		WebElement crd_tab3 = driver.findElement(By.xpath("//div/ul/li/a[@href='#Subscription']"));
		action.moveToElement(crd_tab3).click().perform();

		WebElement history_tab23 = driver.findElement(By.xpath("//div/ul/li/a[@href='#History']"));
		action.moveToElement(history_tab23).click().perform();
		Thread.sleep(3000);

		//scroll to bottom of the page
		JavascriptExecutor js6= (JavascriptExecutor)driver;
		js6.executeScript("window.scrollTo(0,document.body.scrollHeight)","");
		Thread.sleep(3000);

		WebElement createnotes_btn = driver.findElement(By.xpath("//button[@href='javascript: void(0);']"));
		action.moveToElement(createnotes_btn).click().perform();
		Thread.sleep(3000);

		//enter in text field on the pop up
		WebElement text_area = driver.findElement(By.xpath("//*[@id='form-notes']"));
		text_area.sendKeys(generateRandomString());

		//select QC checkbox
		WebElement checkbox_btn = driver.findElement(By.xpath("//*[@id='1']"));
		checkbox_btn.click();
		Thread.sleep(3000);

		//click save button
		WebElement save_button4=driver.findElement(By.xpath("//*[@id='Notesdiv']/div/div[3]/div/div/div/div/div[3]/button[1]"));
		action.moveToElement(save_button4).click().perform();

		log.info("first note  added successfully"); 
		Thread.sleep(3000);

		//add notes with no internal option checked 
		WebElement createnotes_btn1 = driver.findElement(By.xpath("//button[@href='javascript: void(0);']"));
		action.moveToElement(createnotes_btn1).click().perform();
		Thread.sleep(3000);

		//enter in text field on the pop up
		WebElement text_area1 = driver.findElement(By.xpath("//*[@id='form-notes']"));
		text_area1.sendKeys(generateRandomString());

		//uncheck internal checkbox
		WebElement internal_checkbox1 = driver.findElement(By.xpath("//div[2]/div/div/div/div[1]/div/div/div[3]/label/input"));
		internal_checkbox1.click();

		//select QC checkbox
		WebElement checkbox_btn1 = driver.findElement(By.xpath("//*[@id='1']"));
		checkbox_btn1.click();
		Thread.sleep(3000);

		//click save button

		WebElement save_button5=driver.findElement(By.xpath("//*[@id='Notesdiv']/div/div[3]/div/div/div/div/div[3]/button[1]"));
		action.moveToElement(save_button5).click().perform();
		Thread.sleep(3000);

		log.info("second note  added successfully"); 

		//drag the cursor to see notes has been added

		//scroll to bottom of the page
		JavascriptExecutor js7= (JavascriptExecutor) driver;
		js7.executeScript("window.scrollTo(0,document.body.scrollHeight)","");

		//navigate to history tab

		Thread.sleep(3000);
		
		try {
			WebElement crd_tab4 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Subscription']"));
			action.moveToElement(crd_tab4).click().perform();
			
		}
		catch(Exception e) {
			WebElement crd_tab4 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Subscription']"));
			action.moveToElement(crd_tab4).click().perform();
			
		}

		log.info("click on crd tab successfully");
		Thread.sleep(3000);

		try {
			WebElement history_tab1 = driver.findElement(By.xpath("//div/ul/li/a[@href='#History']"));
			action.moveToElement(history_tab1).click().perform();
		}
		catch(Exception e) {
			WebElement history_tab1 = driver.findElement(By.xpath("//div/ul/li/a[@href='#History']"));
			action.moveToElement(history_tab1).click().perform();
			
		}

		log.info("click on history tab successfully");
		Thread.sleep(3000);

		//click on title
		try {
			WebElement title776 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/h4/span"));
			action.moveToElement(title776).click().perform();
		}
		catch(Exception e) {
			WebElement title776 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/h4/span"));
			action.moveToElement(title776).click().perform();	
		}

		log.info("click on title successful");
		Thread.sleep(6000);
	}

	@And("^move the status to complete and validate crd page fields with subscription details page IRM$")
	public void move_the_status_to_complete_and_validate_crd_page_fields_with_subscription_details_page_IRM() throws InterruptedException {
		Actions action = new Actions(driver); 
		//Fetch:---------
		//Term value:
		//Remaining Term:
		//end date

		//scroll to top of the page0
		JavascriptExecutor js777= (JavascriptExecutor) driver;
		js777.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");

		//navigate to cr details tab
		try {
			WebElement crd_tab5 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Subscription']"));
			action.moveToElement(crd_tab5).click().perform();
		}
		catch(Exception e) {
			WebElement crd_tab5 = driver.findElement(By.xpath("//div/ul/li/a[@href='#Subscription']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor. executeScript("arguments[0]. click();", crd_tab5);
		}

         log.info("click on crd tab successfully");
        Thread.sleep(3000);
                
		//submit and validate status
		try {
			WebElement more_actions_btn = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn);
		}
        log.info("click on more actions button successfully");
		Thread.sleep(3000);

		try 
		{
			List<WebElement> options =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Send")) 
				{
                    action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options) 
			{
				if(option.getText().trim().contains("Send")) 
				{
                   action.moveToElement(option).click().perform();;
				}
			}
		}

		//close popup button
		Thread.sleep(3000);		

		log.info("clicked on send status successfully");
		Thread.sleep(3000);
		
		//add an opportunity
		WebElement link_opportunity =  driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div/a/i"));
		link_opportunity.click();
		Thread.sleep(3000);
		
		driver.switchTo().activeElement();
		
		WebElement radio_butn = driver.findElement(By.xpath("//table/tbody/tr[1]/td[1]/input"));
		radio_butn.click();
		
		WebElement link_button =  driver.findElement(By.xpath("//button[contains(text(),'Link')]"));
		link_button.click();
		
	    log.info("opportunity added successfully");
	    Thread.sleep(3000);
	    
		//click on disable preorder
		try {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			action.moveToElement(disable_preorderV).click().perform();
		}
		catch(Exception e) {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", disable_preorderV);
		}

		    log.info("clicked on disable preorder successfully");
		    Thread.sleep(6000);
	    
		
        //scroll to top of the page
		JavascriptExecutor js77= (JavascriptExecutor) driver;
		js77.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");
		
		//move the sub to complete status
		try {
			WebElement more_actions_btn2 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn2).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn2 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn2);
		}

		Thread.sleep(4000);

		try 
		{
			List<WebElement> options2 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options2) 
			{
				if(option.getText().trim().contains("Send for Verification")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options2 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options2) 
			{
				if(option.getText().trim().contains("Send for Verification")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}

		//close popup button
		Thread.sleep(3000);		
		log.info("clicked on send for verification successfully");

		Thread.sleep(3000);

		//validate status is moved to verification
		WebElement status_sub = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div/h4/span"));
		String status = status_sub.getText();

		Assert.assertEquals("Verification", status);

		// move to next status
		try {
			WebElement more_actions_btn4 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn4).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn4 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn4);
		}

		Thread.sleep(4000);

		try 
		{
			List<WebElement> options4 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options4) 
			{
				if(option.getText().trim().contains("Edit QC")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options4 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options4) 
			{
				if(option.getText().trim().contains("Edit QC")) 
				{
                    action.moveToElement(option).click().perform();
				}
			}
		}

		//edit QC information on popup
		driver.switchTo().activeElement();
		Thread.sleep(5000);
		log.info("clicked on Edit QC successfully");

		WebElement check_box1 = driver.findElement(By.xpath("//input[@id='8'][@type='checkbox']"));
		check_box1.click();

		WebElement check_box2 = driver.findElement(By.xpath("//input[@id='32'][@type='checkbox']"));
		check_box2.click();

		WebElement check_box3 = driver.findElement(By.xpath("//input[@id='512'][@type='checkbox']"));
		check_box3.click();

		WebElement check_box4 = driver.findElement(By.xpath("//input[@id='1024'][@type='checkbox']"));
		check_box4.click();

		//select QC Analyst
		WebElement Drpdwnqc = driver.findElement(By.xpath("//div[3]/div/div/div/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/select"));
		action.moveToElement(Drpdwnqc).click().perform();
		Drpdwnqc.click();

		Select DrpdwnAnyOptionqc = new Select(driver.findElement(By.xpath("//div[3]/div/div/div/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/select")));		
		DrpdwnAnyOptionqc.selectByIndex(3);

		//enter text
		WebElement qc_note1 = driver.findElement(By.xpath("//div[3]/div/div/div/div/div[2]/div[2]/div/div[2]/div[4]/div[2]/textarea"));
		qc_note1.sendKeys(generateRandomString());

		//click on save button 
		WebElement save_button = driver.findElement(By.xpath("//div[3]/div/div/div/div/div[3]/button[1]"));
		save_button.click();
		Thread.sleep(3000);

		//navigate to cod tab and validate above fields
		Thread.sleep(5000);

		// move to next status
		Thread.sleep(3000);

		try {
			WebElement more_actions_btn5 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn5).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn5 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn5);
		}

		Thread.sleep(3000);

		try 
		{
			List<WebElement> options5 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options5) 
			{
				if(option.getText().trim().contains("Edit QC")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options5 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options5) 
			{
				if(option.getText().trim().contains("Edit QC")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}

		//edit QC information on popup
		driver.switchTo().activeElement();
		Thread.sleep(5000);

		WebElement check3_box1 = driver.findElement(By.xpath("//input[@id='8'][@type='checkbox']"));
		check3_box1.click();

		WebElement check3_box2 = driver.findElement(By.xpath("//input[@id='32'][@type='checkbox']"));
		check3_box2.click();

		WebElement check3_box3 = driver.findElement(By.xpath("//input[@id='512'][@type='checkbox']"));
		check3_box3.click();

		WebElement check3_box4 = driver.findElement(By.xpath("//input[@id='1024'][@type='checkbox']"));
		check3_box4.click();

		WebElement release_verification = driver.findElement(By.xpath("//div/div[1]/div/div[3]/div/div/div/div/div[3]/button[2]"));
		release_verification.click();
		Thread.sleep(5000);		

		//validate status is moved to Credit HOLD
		WebElement status_sub1 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div/h4/span"));
		String status1 = status_sub1.getText();

		//validate the status
		Assert.assertEquals("Credit Hold", status1);

		log.info("moved to credit hold status successfully");

		// move to next status
		try {
			WebElement more_actions_btn6 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn6).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn6 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn6);
		}

		Thread.sleep(3000);

		try 
		{
			List<WebElement> options6 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options6) 
			{
				if(option.getText().trim().contains("Release Credit Hold")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options6 =  driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options6) 
			{
				if(option.getText().trim().contains("Release Credit Hold")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}

		//close popup button
		Thread.sleep(3000);		

		log.info("moved to relese credit hold status successfully");

		//validate status is moved to infulfilment
		WebElement status2_sub2 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div/h4/span"));
		String status3 = status2_sub2.getText();

		// //validate the status
		Assert.assertEquals("InFulfillment", status3);
        
		log.info("moved to infulfillment status successfully");
		
		//click on disable preorder
		try {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			action.moveToElement(disable_preorderV).click().perform();
		}
		catch(Exception e) {
			WebElement disable_preorderV = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[3]"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", disable_preorderV);
		}

		    log.info("clicked on disable preorder successfully");
		    Thread.sleep(6000);

        //scroll to top of the page
		JavascriptExecutor js787= (JavascriptExecutor) driver;
		js787.executeScript("window.scrollTo(0,-document.body.scrollHeight)","");
		
		// move to next status
		try {
			WebElement more_actions_btn7 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn7).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn7 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn7);
		}

		Thread.sleep(3000);

		try 
		{
			List<WebElement> options7 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options7) 
			{
				if(option.getText().trim().contains("Submit")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options7 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options7) 
			{
				if(option.getText().trim().contains("Submit")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}

		//close popup button
		Thread.sleep(3000);		
		log.info("clicked on submit status successfully");

		Thread.sleep(3000);

		//validate status is moved to submitted to vendor
		WebElement status3_sub3 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div/h4/span"));
		String status4 = status3_sub3.getText();

		// //validate the status
		Assert.assertEquals("Submitted To Vendor", status4);	
		log.info("moved to submitted to vendor status successfully");

		// move to next status
		try {
			WebElement more_actions_btn9 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn9).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn9 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn9);
		}

		Thread.sleep(4000);

		try 
		{
			List<WebElement> options9 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options9) 
			{
				if(option.getText().trim().contains("Pending Provisioning")) 
				{
					action.moveToElement(option).perform();
					option.click();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options9 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options9) 
			{
				if(option.getText().trim().contains("Pending Provisioning")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}

		//close popup button
		Thread.sleep(3000);		

		//validate status is moved to pending provisioning
		WebElement status4_sub4 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div/h4/span"));
		String status5 = status4_sub4.getText();

		//validate the status
		Assert.assertEquals("Pending Provisioning", status5);
		log.info("moved to pending provisioning status successfully");

		//Add a line item
		Thread.sleep(3000);

		JavascriptExecutor js8 = (JavascriptExecutor)driver;
		js8.executeScript("window.scrollBy(0,420)", "");

		WebElement add_lineitem = driver.findElement(By.xpath("//*[@id=\"table-vertical-scroll\"]/div[2]/div[1]/button[1]"));
		add_lineitem.click();

		//select catalog dropdown
		driver.switchTo().activeElement();

		Thread.sleep(5000);

		WebElement Drpdwnli1 = driver.findElement(By.xpath("//div[5]/div[2]/div/div/div/div/div[2]/div/div/div[1]/div[1]/div[2]/select"));
		action.moveToElement(Drpdwnli1).click().perform();
		Drpdwnli1.click();

		Thread.sleep(5000);

		Select DrpdwnAnyOption1li = new Select(driver.findElement(By.xpath("//div[5]/div[2]/div/div/div/div/div[2]/div/div/div[1]/div[1]/div[2]/select")));		
		DrpdwnAnyOption1li.selectByIndex(3);

		//select manufacturer dropdown
		WebElement Drpdwnli2 = driver.findElement(By.xpath("//div[5]/div[2]/div/div/div/div/div[2]/div/div/div[1]/div[2]/div[2]/select"));
		action.moveToElement(Drpdwnli2).click().perform();
		Drpdwnli2.click();

		Thread.sleep(5000);

		Select DrpdwnAnyOption2li = new Select(driver.findElement(By.xpath("//div[5]/div[2]/div/div/div/div/div[2]/div/div/div[1]/div[2]/div[2]/select")));		
		DrpdwnAnyOption2li.selectByIndex(3);

		//click on search button
		WebElement search_button = driver.findElement(By.xpath("//button/i[@class='fas fa-search']"));
		search_button.click();

		//click on add button
		WebElement addclose_button = driver.findElement(By.xpath("//button[contains(text(),'Add & Close')]/i[@class='fas fa-plus']"));
		addclose_button.click();

		log.info("Added line items successfully");

		Thread.sleep(5000);

		//validate manufacturer part with subscription detials page - customer details tab
		// move to next status

		JavascriptExecutor js9 = (JavascriptExecutor)driver;
		js9.executeScript("window.scrollBy(0,420)", "");

		Thread.sleep(3000);
		
		//enter start date
		action.moveToElement(driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div/div[1]/div/input")));
		action.click();
		action.sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE);
		Thread.sleep(3000);			
        action.sendKeys(date1);
        Thread.sleep(3000);
        action.build().perform();
        
		//enter end date        
		WebElement end_date = driver.findElement(By.xpath("//div[2]/div[3]/div[2]/div/div[1]/div/input"));
		end_date.sendKeys(date1);
		Thread.sleep(3000);
		
		try {
			WebElement more_actions_btn10 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			action.moveToElement(more_actions_btn10).click().perform();
		}
		catch(Exception e) {
			WebElement more_actions_btn10 = driver.findElement(By.xpath("//*[@id='btnGroupVerticalDrop1']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver; 
			executor.executeScript("arguments[0].click();", more_actions_btn10);
		}

		Thread.sleep(3000);

		try 
		{
			List<WebElement> options10 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options10) 
			{
				if(option.getText().trim().contains("Mark Complete")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			List<WebElement> options10 =    driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for(WebElement option : options10) 
			{
				if(option.getText().trim().contains("Mark Complete")) 
				{
					action.moveToElement(option).click().perform();
				}
			}
		}

		//close popup button
		Thread.sleep(5000);		

		//validate status is moved to complete

		WebElement status5_sub5 = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[1]/div/h4/span"));
		String status6 = status5_sub5.getText();

		// //validate the status
		Assert.assertEquals("Complete", status6);

		log.info("Moved to complete successfully");

		try {
			WebElement history_tab6 = driver.findElement(By.xpath("//div/ul/li/a[@href='#History']"));
			action.moveToElement(history_tab6).click().perform();
		}
		catch(Exception e) {
			WebElement history_tab6 = driver.findElement(By.xpath("//div/ul/li/a[@href='#History']"));
			action.moveToElement(history_tab6).click().perform();
			
		}

		log.info("click on history tab successfully");
		Thread.sleep(3000);

       //click on crd tab

		try{

        WebElement crd_tab89 = driver.findElement(By.xpath("//div/ul/li/a[@href='#Subscription']"));
		action.moveToElement(crd_tab89).click().perform();
		
		} catch(Exception e){
		
		WebElement crd_tab89 = driver.findElement(By.xpath("//div/ul/li/a[@class='nav-link'][@href='#Subscription']"));
		action.moveToElement(crd_tab89).click().perform();

		}

		log.info("clicked on crd tab successfully");
		Thread.sleep(8000);

		//navigate to sub details page
		WebElement sub_hyperlink = driver.findElement(By.xpath("//*[@id=\"col1\"]/div/div[1]/div[3]/div[2]/a"));
		sub_hyperlink.click();

		driver.switchTo().defaultContent();

		Set<String> allWindowHandles = driver.getWindowHandles();

		for ( String currHandle : allWindowHandles) {

			driver.switchTo().window(currHandle);
		}

		String url = driver.getCurrentUrl();
		log.info("("+url+")");

		//validate the change request number & line item added after complete in Sub details page

		Thread.sleep(3000);
		JavascriptExecutor js10 = (JavascriptExecutor) driver;
		js10.executeScript("window.scrollTo(0,document.body.scrollHeight)","");

		//navigate to history tab

		Thread.sleep(3000);

		WebElement history_tab4 = driver.findElement(By.xpath("//div/ul/li/a[@href='#History']"));
		action.moveToElement(history_tab4).click().perform();

		log.info("clicked on history tab successfully");
		Thread.sleep(5000);
	}

	@And("^user close the subscriptions details page IRM$") 
	public void user_close_the_subscription_details_page_IRM() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
			
			log.info("User close the subscriptions details page");
		}

	}

	@And("^user close the change request details page IRM$")
	public void user_close_the_change_request_details_page_IRM() throws InterruptedException {
		driver.switchTo().defaultContent();

		@SuppressWarnings("unused")
		String parentwindow = driver.getWindowHandle();

		Set<String> allwindowhandles = driver.getWindowHandles();

		for(String currwindow : allwindowhandles) {

			driver.switchTo().window(currwindow);
			Thread.sleep(1000);
		}

		driver.close();

		Thread.sleep(1000);	    	    
		for(@SuppressWarnings("unused") String currwindow1 : allwindowhandles) {

			driver.switchTo().window(allwindowhandles.iterator().next());
			Thread.sleep(1000);
		}
		log.info("User close the change request details page");
	}

	@And("^user clicks on logout IRM$")
	public void user_clicks_on_logout_IRM() throws InterruptedException {

		Actions action = new Actions(driver);

		action.moveToElement(driver.findElement(By.xpath("//*[@id='page-header-user-dropdown']"))).click().perform();
		Thread.sleep(5000);

		WebElement logout = driver.findElement(By.xpath("//span[contains(text(),'Logout')]"));	
		action.moveToElement(logout).click().perform();
		
		log.info("User clicks on logout");
	}

	@And("^close the browser IRM$")
	public void close_the_browser_IRM() {
		driver.quit();
		log.info("Close the browser");
	}
}