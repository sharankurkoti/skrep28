package com.presidio.qa.pages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.presidio.qa.base.TestBase;

public class UserAccountsPage extends TestBase{
	@FindBy(xpath="//*[@id=\"main-content\"]/div/div[1]")
	WebElement UserAccountsPagelabel;
	
	String removedWord = null;
	String OriginalString = null;
	
	//Initializing the Page Objects:
	
	public UserAccountsPage() {
		PageFactory.initElements(driver,this);
	}
	
	public String UserAccountsPagelabel() {
		return UserAccountsPagelabel.getText();
	}
	
	public String Removefirstword(String OriginalString)
	{
	//	int spaceIdx = OriginalString.indexOf(" ");
	//	removedWord = OriginalString.substring(0,spaceIdx);
	//	OriginalString = OriginalString.substring(spaceIdx);
		OriginalString = OriginalString.substring(3);
		
		 return OriginalString;
	}
			
}