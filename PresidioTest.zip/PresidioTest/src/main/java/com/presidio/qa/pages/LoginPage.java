package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class LoginPage extends TestBase {
	
	
	//Page Factory - OR:
	
	
	@FindBy(xpath="//input[@id='exampleInputEmail1']")
	WebElement username;
	
	@FindBy(xpath="//input[@id='exampleInputPassword1']")
	WebElement password;
	
	@FindBy(xpath="//button[contains(text(),'Sign In')]")
	WebElement SignInBtn;
	
	
	@FindBy(xpath="//button[contains(text(),'Register')]")
	WebElement RegisterBtn;
	
	@FindBy(xpath="//div[contains(text(),'Portal')]")
	WebElement PresidioLogo;
	
	@FindBy(xpath="//a[contains(text(),'Login')]")
	WebElement LoginBtn;
	
	@FindBy(xpath="//a[contains(text(),'Help')]")
	WebElement HelpBtn;
	
	@FindBy(xpath="//header/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/a[1]/i[1]")
	WebElement HomeIcon;
	
		
	
	//Initializing the Page Objects:
	//To initialize all above OR, with the help of page factory i create constructor of the class 
	public LoginPage() {
		PageFactory.initElements(driver, this);//this means its pointing to current class
			
	}
	
	//Actions
	public String validateLoginPageTitle() {
		return driver.getTitle();
	}
	
	public boolean validatePresidioLogo() {
		return PresidioLogo.isDisplayed();
	}
	 
   public HomePage login(String uname, String pword) throws InterruptedException {
	   username.sendKeys(uname);
	   password.sendKeys(pword);
	   SignInBtn.click();
	   Thread.sleep(10000);
	   
	   return new HomePage();
   }
		
	
}
