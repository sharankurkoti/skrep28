package com.presidio.qa.pages;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class ShoppingcartPage extends TestBase{
	@FindBy(xpath="//*[@id=\"main-content\"]/div/div[1]")
	WebElement ShoppingcartPagelabel;
	
	//Initializing the Page Objects:
	
	public ShoppingcartPage() {
		PageFactory.initElements(driver,this);
		
	}
	
	public String ShoppingcartPagelabel() {
		return ShoppingcartPagelabel.getText();
	}
		
	public String replaceSpacewithHypn(String str) {
		if (str != null && str.trim().length()>0) {
			String patternStr = "\\s+";
			String replaceStr = "-";
			Pattern pattern = Pattern.compile(patternStr);
			Matcher matcher = pattern.matcher(str);
			str = matcher.replaceAll(replaceStr);
			patternStr = "\\s";
			replaceStr = "-";
			pattern = Pattern.compile(patternStr);
			matcher = pattern.matcher(str);
			str = matcher.replaceAll(replaceStr);
		}
		return str;
	}
	
}
 