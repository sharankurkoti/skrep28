package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class ShopPage extends TestBase {
	@FindBy(xpath="//span[contains(text(),'SHOP')]")
	WebElement ShopPagelabel;
	
	//Initializing the Page Objects:
	
	public ShopPage() {
		PageFactory.initElements(driver,this);
	}
	
	public String ShopPagelabel() {
		return ShopPagelabel.getText();
	}

}