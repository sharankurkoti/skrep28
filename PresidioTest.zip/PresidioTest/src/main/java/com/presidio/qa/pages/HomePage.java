package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class HomePage extends TestBase {

	
	@FindBy(xpath="//header/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[2]/a[1]")
	WebElement userNameLable;	
	
	@FindBy(xpath="//span[contains(text(),'TRACK ORDER STATUS')]")
	WebElement TrackOrderStatuslink;
	
	@FindBy(xpath="//span[contains(text(),'SHOP')]")
	WebElement Shoplink ;
	
	@FindBy(xpath="//span[contains(text(),'Quotes')]")
	WebElement Quoteslink;
	
	@FindBy(xpath="//span[contains(text(),'Orders')]")
	WebElement Orderslink;
	
	@FindBy(xpath="//span[contains(text(),'Invoices')]")
	WebElement Invoiceslink;
	
	@FindBy(xpath="//span[contains(text(),'Cisco Service Center')]")
	WebElement CiscoServiceCenterlink;
	
	@FindBy(xpath="//span[contains(text(),'Reports')]")
	WebElement Reportslink;
	
	@FindBy(xpath="//header/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]")
	WebElement Alldocumentslink;
	
	@FindBy(xpath="//*[@id=\"upper-nav\"]/ul/li[1]/a/i")
	WebElement HomeIconlink;
	
	@FindBy(xpath="//*[@id=\"upper-nav\"]/ul/li[2]/a")
	WebElement UserAccountslink ;
	
	@FindBy(xpath="//a[contains(text(),'Help')]")
	WebElement Helplink;
	
	@FindBy(xpath="//span[@id='portalsDropdown']")
	WebElement Presidioportallink;
	
	@FindBy(xpath="//*[@id=\"upper-nav\"]/ul/li[6]/a/i")
	WebElement Settingslink;
	
	@FindBy(xpath="//*[@id=\"middle-nav\"]/form/div/input")
	WebElement Searchtextboxlink ;
	 
	@FindBy(xpath="//*[@id=\"middle-nav\"]/div[2]/a/div")
	WebElement Shoppingcartlink ;
	
	//Initializing the Page Objects:
	
	public HomePage() 
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public String verifyHomePageTitle() 
	
	{
       return driver.getTitle();	
	}
	
	public boolean verifyCorrectUserName() {
		 return userNameLable.isDisplayed();
		 
	}
	
    public TrackorderstatusPage ClickOnTrackOrderStatuslink() 
    {
    	TrackOrderStatuslink.click();
    	return new TrackorderstatusPage();
    }
	
	public QuotesPage ClickOnQuoteslink() 
	{
		Actions action = new Actions(driver);
		
		action.moveToElement(Quoteslink).perform();
		
		Quoteslink.click();
		return new QuotesPage();
	}
	
	public ShopPage ClickOnShoplink()
	{
		Shoplink.click();
		return new ShopPage();
	}
	
	public OrdersPage ClickOnOrderslink() 
	{
		Orderslink.click();
		return new OrdersPage();
	}
	
	public InvoicesPage ClickOnInvoiceslink() 
	{
		Invoiceslink.click();
		return new InvoicesPage();
	}
	
	public CiscoservicecenterPage ClickOnCiscoServiceCenterlink() 
	{
		CiscoServiceCenterlink.click();
		return new CiscoservicecenterPage();
	}
	
	public ReportsPage ClickOnReportslink() 
	{
		Reportslink.click();
		return new ReportsPage();
	}
	
	public AlldocumentsPage ClickOnAlldocumentslink() 
	{
		Alldocumentslink.click();
		return new AlldocumentsPage();
	}
		
	public UserAccountsPage ClicOnkUserAccountslink() 
	{
		UserAccountslink.click();
		return new UserAccountsPage();
	}
	
	public HelpPage ClickOnHelplink() 
	{
		Helplink.click();
		return new HelpPage();
	}
	
	public PresidioPortalsPage clickOnPresidioportallink() 
	{
		Presidioportallink.click();
		return new PresidioPortalsPage();
	}
	
	public SettingsPage clickOnSettingslink() 
	{
		Settingslink.click();
		return new SettingsPage();
	}
	
	public SearchtextboxPage clickOnSearchtextboxlink() 
	{
		Searchtextboxlink.click();
		return new SearchtextboxPage();
	}
		
	public ShoppingcartPage clickOnShoppingcartlink() 
	{
		Shoppingcartlink.click();
		return new ShoppingcartPage();
	}
}
