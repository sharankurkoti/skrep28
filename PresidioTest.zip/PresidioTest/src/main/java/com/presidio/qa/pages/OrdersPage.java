package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class OrdersPage extends TestBase {

	@FindBy(xpath="//span[contains(text(),'Orders')]")
	WebElement Orderslink;

	@FindBy(xpath="//*[@id=\"jumbotron\"]/ul/li[8]/div/div/span[2]/a")
	WebElement Orderslink2;
	
	@FindBy(xpath="//*[@id=\"main-content\"]/div/div/div[1]/div[1]/div")
	WebElement OrdersPagelabel;
	
	//Initializing the Page Objects:
	
	public OrdersPage() {
		PageFactory.initElements(driver,this);
	}
	
	public OrdersPage ClickOnOrderslink() 
	{
		Actions action = new Actions(driver);
		
		action.moveToElement(Orderslink).perform();
	    action.moveToElement(Orderslink2).perform();
		
		Orderslink2.click();
		return new OrdersPage();
	}
	
	public String OrdersPagelabel() {
		return OrdersPagelabel.getText();
	}
}
