package com.presidio.qa.pages;

import com.presidio.qa.base.TestBase;

public class ReportsPage extends TestBase{

}
