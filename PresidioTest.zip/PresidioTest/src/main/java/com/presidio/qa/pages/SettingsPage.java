package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class SettingsPage extends TestBase {

	@FindBy(xpath="//*[@id=\"main-content\"]/div/div/div")
	WebElement SettingsPagelabel;
	
	//Initializing the Page Objects:
	
	public SettingsPage() {
		PageFactory.initElements(driver,this);
	}
	
	public String SettingsPagelabel() {
		return SettingsPagelabel.getText();
	}
	
	public String removespace(String OrigStr) {
		
	     OrigStr = OrigStr.replaceAll("\\s{2}", "");
	    
	    return OrigStr;
	}
}
