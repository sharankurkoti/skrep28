package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class HelpPage extends TestBase {
	@FindBy(xpath="//*[@id=\"main-content\"]/div/div[1]")
	WebElement HelpPagelabel;
	
	//Initializing the Page Objects:
	
	public HelpPage() {
		PageFactory.initElements(driver,this);
	}
	
	public String HelpPagelabel() {
		return HelpPagelabel.getText();
	}

}