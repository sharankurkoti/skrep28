package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class RequisitionsPage extends TestBase {

	@FindBy(xpath="//span[contains(text(),'Orders')]")
	WebElement Orderslink;

	@FindBy(xpath="//*[@id=\"jumbotron\"]/ul/li[8]/div/div/span[1]/a")
	WebElement Requisitionslink;
	
	@FindBy(xpath="//*[@id=\"main-content\"]/div/div[1]/div[1]/div")
	WebElement RequisitionsPagelabel;
	
	//Initializing the Page Objects:
	
	public RequisitionsPage() {
		PageFactory.initElements(driver,this);
	}
	
	public RequisitionsPage ClickOnRequisitionslink() 
	{
		Actions action = new Actions(driver);
		
		action.moveToElement(Orderslink).perform();
	    action.moveToElement(Requisitionslink).perform();
		
		Requisitionslink.click();
		return new RequisitionsPage();
	}
	
	public String RequisitionsPagelabel() {
		return RequisitionsPagelabel.getText();
	}
}
