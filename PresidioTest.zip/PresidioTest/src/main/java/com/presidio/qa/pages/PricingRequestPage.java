package com.presidio.qa.pages;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class PricingRequestPage extends TestBase{
	@FindBy(xpath="//body[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]")
	WebElement PricingRequestPagelabel;
		
	@FindBy(xpath="//*[@id=\"jumbotron\"]/ul/li[5]/div/div/span[2]/a")
	WebElement PricingRequestlink;
	
	@FindBy(xpath="//span[contains(text(),'Quotes')]")
	WebElement Quoteslink;
	
	//Initializing the Page Objects:
	
	public PricingRequestPage() {
		PageFactory.initElements(driver,this);
	}
	
	public String PricingRequestPagelabel() {
		return PricingRequestPagelabel.getText();
	}
	
	public PricingRequestPage ClickOnPricingRequestlink() 
	{
		Actions action = new Actions(driver);
		
		action.moveToElement(Quoteslink).perform();
		action.moveToElement(PricingRequestlink).perform();
		
		PricingRequestlink.click();
		return new PricingRequestPage();
	}
	
	public String replaceSpacewithHypn(String str) {
		if (str != null && str.trim().length()>0) {
			String patternStr = "\\s+";
			String replaceStr = "-";
			Pattern pattern = Pattern.compile(patternStr);
			Matcher matcher = pattern.matcher(str);
			str = matcher.replaceAll(replaceStr);
			patternStr = "\\s";
			replaceStr = "-";
			pattern = Pattern.compile(patternStr);
			matcher = pattern.matcher(str);
			str = matcher.replaceAll(replaceStr);
		}
		return str;
	}
	
}