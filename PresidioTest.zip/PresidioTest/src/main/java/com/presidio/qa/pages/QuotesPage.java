package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class QuotesPage extends TestBase{
	
	@FindBy(xpath="//span[contains(text(),'Quotes')]")
	WebElement Quoteslink;

	@FindBy(xpath="//*[@id=\"jumbotron\"]/ul/li[5]/div/div/span[1]/a")
	WebElement Quoteslink2;
	
	@FindBy(xpath="//*[@id=\"main-content\"]/div/div/div[1]/div[1]/div")
	WebElement QuotesPagelabel;
	
	//Initializing the Page Objects:
	
	public QuotesPage() {
		PageFactory.initElements(driver,this);
	}
	
	public QuotesPage ClickOnQuoteslink() 
	{
		Actions action = new Actions(driver);
		
		action.moveToElement(Quoteslink).perform();
	    action.moveToElement(Quoteslink2).perform();
		
		Quoteslink2.click();
		return new QuotesPage();
	}
	
	public String QuotesPagelabel() {
		return QuotesPagelabel.getText();
	}
}