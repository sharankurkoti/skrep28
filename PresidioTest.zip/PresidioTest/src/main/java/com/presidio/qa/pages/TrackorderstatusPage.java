package com.presidio.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.presidio.qa.base.TestBase;

public class TrackorderstatusPage extends TestBase {
	
	@FindBy(xpath="//body[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]")
	WebElement Trackorderstatuslable;
	
	//Initializing the Page Objects:
	
	public TrackorderstatusPage() {
		PageFactory.initElements(driver,this);
	}
	
	public String Trackorderstatuslable() {
		return Trackorderstatuslable.getText();			
	}
}
