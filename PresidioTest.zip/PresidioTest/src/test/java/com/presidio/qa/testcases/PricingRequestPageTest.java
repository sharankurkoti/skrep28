package com.presidio.qa.testcases;
import static org.testng.Assert.assertEquals;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.presidio.qa.base.TestBase;
import com.presidio.qa.pages.HomePage;
import com.presidio.qa.pages.LoginPage;
import com.presidio.qa.pages.PricingRequestPage;

public class PricingRequestPageTest extends TestBase {

	LoginPage loginPage;
	HomePage homePage;
	PricingRequestPage pricingRequestPage;

	public  PricingRequestPageTest() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	@BeforeMethod
	public void setUp() throws InterruptedException
	{
		initialization();
		//create object of login page class
		loginPage = new LoginPage();
		pricingRequestPage= new PricingRequestPage();
	
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));	
		
		pricingRequestPage = pricingRequestPage.ClickOnPricingRequestlink();
	}
	
	@Test(priority=1)
	public void verifyPricingRequestPagelabel() throws InterruptedException {
			
		Thread.sleep(10000);
        String request_uri = null;
        String url = driver.getCurrentUrl();
        String s = null;
        System.out.println (url);	
		
	    if (url.startsWith("https://")) {
        request_uri = url.substring(7).split("/")[3];
        } else {
        request_uri = url.split("/")[3];
		}
		System.out.println (request_uri);
		
		String PricingRequestPagelabel = pricingRequestPage.PricingRequestPagelabel();
		String str1 =  PricingRequestPagelabel.toLowerCase();
				
		System.out.println (PricingRequestPagelabel);
		System.out.println (str1);
		
		s = pricingRequestPage.replaceSpacewithHypn(str1);
		
		System.out.println (s);
				
		assertEquals(s, request_uri);
		Assert.assertTrue(true);		    		
	}	
				
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}	
	
}