package com.presidio.qa.testcases;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.presidio.qa.base.TestBase;
import com.presidio.qa.pages.HomePage;
import com.presidio.qa.pages.LoginPage;
import com.presidio.qa.pages.QuotesPage;

import com.presidio.qa.util.TestUtil;

public class QuotesPageTest extends TestBase{

	
	LoginPage loginPage;
	HomePage homePage;
	TestUtil testUtil;
	QuotesPage quotesPage;

	public QuotesPageTest() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	@BeforeMethod
	public void setUp() throws InterruptedException
	{
		initialization();
		//create object of login page class
		loginPage = new LoginPage();
		quotesPage= new QuotesPage();
	
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));	
		quotesPage = quotesPage.ClickOnQuoteslink();
		
	}
	
	@Test(priority=1)
	public void verifyQuotesPagelabel() throws InterruptedException {
			
		Thread.sleep(10000);
        String request_uri = null;
        String url = driver.getCurrentUrl();
        System.out.println (url);	
		
	    if (url.startsWith("https://")) {
        request_uri = url.substring(7).split("/")[3];
        } else {
        request_uri = url.split("/")[3];
		}
		System.out.println (request_uri);
		
		String QuotesPagelabel = quotesPage.QuotesPagelabel();
		String str1 =  QuotesPagelabel.toLowerCase();
		
		System.out.println (QuotesPagelabel);
		System.out.println (str1);
						
		assertEquals(str1, request_uri);
		Assert.assertTrue(true);		    		
	}	
				
    //@Test(priority=2, dataProvider="getPresidioTestData")
    //public void SearchQuotes() {
    	
    //}
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	
}
