package com.presidio.qa.testcases;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.presidio.qa.base.TestBase;
import com.presidio.qa.pages.HomePage;
import com.presidio.qa.pages.LoginPage;

public class LoginPageTest extends TestBase {
	LoginPage loginPage;
	HomePage homePage;
	
    public LoginPageTest() {
    	super();//super keyword: first it will call test base call constructor
    }
	
	@BeforeMethod
	public void setUp(){
		initialization();
		//create object of login page class
		loginPage = new LoginPage();
	}

	@Test(priority=1)
	public void LoginPageTitleTest() {
		String title = loginPage.validateLoginPageTitle();
		Assert.assertEquals(title, "Login");//validation
	}

	@Test(priority=2)
	public void PresidioLogoImageTest() {
		boolean flag = loginPage.validatePresidioLogo();
		Assert.assertTrue(flag);
	}
	
	@Test(priority=3)
	public void loginTest() throws InterruptedException {
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		Thread.sleep(10000);
		 	
	}
		
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	
}
