package com.presidio.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.presidio.qa.base.TestBase;
import com.presidio.qa.pages.AlldocumentsPage;
import com.presidio.qa.pages.CiscoservicecenterPage;
import com.presidio.qa.pages.HelpPage;
import com.presidio.qa.pages.HomePage;
import com.presidio.qa.pages.InvoicesPage;
import com.presidio.qa.pages.LoginPage;
import com.presidio.qa.pages.OrdersPage;
import com.presidio.qa.pages.PresidioPortalsPage;
import com.presidio.qa.pages.QuotesPage;
import com.presidio.qa.pages.ReportsPage;
import com.presidio.qa.pages.SearchtextboxPage;
import com.presidio.qa.pages.SettingsPage;
import com.presidio.qa.pages.ShopPage;
import com.presidio.qa.pages.TrackorderstatusPage;
import com.presidio.qa.pages.UserAccountsPage;

public class HomePageTest extends TestBase
{
	LoginPage loginPage;
	HomePage homePage;
	TrackorderstatusPage trackorderstatusPage;
	QuotesPage quotesPage;
	ShopPage shopPage;
	OrdersPage ordersPage;
	InvoicesPage invoicesPage;
	CiscoservicecenterPage ciscoservicecenterPage;
	ReportsPage reportsPage;
	AlldocumentsPage alldocumentsPage;
	UserAccountsPage userAccountsPage;
	HelpPage helpPage;
	PresidioPortalsPage presidioPortalsPage;
	SettingsPage settingsPage;
	SearchtextboxPage searchtextboxPage;
	
	public HomePageTest() 
	{
    	super();
    }
	
	@BeforeMethod
	public void setUp() throws InterruptedException
	{
		initialization();
		//create object of login page class
		loginPage = new LoginPage();
		trackorderstatusPage= new TrackorderstatusPage();
		quotesPage = new QuotesPage();	
		shopPage = new ShopPage();
		ordersPage = new OrdersPage();
		invoicesPage = new InvoicesPage();
		ciscoservicecenterPage = new CiscoservicecenterPage();
		reportsPage = new ReportsPage();
		alldocumentsPage = new AlldocumentsPage();
		userAccountsPage = new UserAccountsPage();
		helpPage = new HelpPage();
		presidioPortalsPage = new PresidioPortalsPage();
		settingsPage = new SettingsPage();
		searchtextboxPage = new SearchtextboxPage();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));	
	}
	
	@Test(priority=1)
	public void verifyHomePageTitleTest() 
	{
		String homePageTitle = homePage.verifyHomePageTitle();
		Assert.assertEquals(homePageTitle,"Login"," Home Page Title not matched");	
	}
	
	@Test(priority=2)
	public void verifyUserNameTest() 
	{
		homePage.verifyCorrectUserName();
		Assert.assertTrue(homePage.verifyCorrectUserName());
	}
	
	@Test(priority=3)
	public void verifyTrackOrderStatuslink() 
	{
		trackorderstatusPage = homePage.ClickOnTrackOrderStatuslink();
	}
	
	@Test(priority=4)
    public void verifyQuoteslink() 
	{	
		quotesPage = homePage.ClickOnQuoteslink();
	}
	
	@Test(priority=5)
    public void verifyShoplink() 
	{
	   shopPage = homePage.ClickOnShoplink();
		
	}
	
	@Test(priority=6)
    public void verifyOrderslink() 
	{
       ordersPage = homePage.ClickOnOrderslink();		
	}
	
	@Test(priority=7)
    public void verifyInvoiceslink() 
	{
		invoicesPage = homePage.ClickOnInvoiceslink();
	}
	
	@Test(priority=8)
    public void verifyCiscoServiceCenterlink() 
	{
		ciscoservicecenterPage = homePage.ClickOnCiscoServiceCenterlink();
	}
	
	@Test(priority=9)
    public void verifyReportslink() 
	{
	    reportsPage = homePage.ClickOnReportslink();
	    
	}
	
	@Test(priority=10)
    public void verifyAlldocumentslink() 
	{
		alldocumentsPage = homePage.ClickOnAlldocumentslink();
	}
	
	@Test(priority=11)
    public void verifyUserAccountslink() 
	{
	      userAccountsPage = homePage.ClicOnkUserAccountslink();
	}
	
	@Test(priority=12)
    public void verifyHelplink() 
	{
	      helpPage = homePage.ClickOnHelplink();	
	}
	
	@Test(priority=13)
    public void verifyPresidioportallink() 
	{
	      presidioPortalsPage = homePage.clickOnPresidioportallink();	
	}
	
	@Test(priority=14)
    public void verifySettingslink() 
	{
	      settingsPage = homePage.clickOnSettingslink();	
	}	
	
	@Test(priority=15)
    public void verifySearchtextboxlink() 
	{
          searchtextboxPage = homePage.clickOnSearchtextboxlink();		
	}	
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
		
}