package com.presidio.qa.testcases;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.presidio.qa.base.TestBase;
import com.presidio.qa.pages.HomePage;
import com.presidio.qa.pages.LoginPage;
import com.presidio.qa.pages.SettingsPage;

public class SettingsPageTest extends TestBase {
	LoginPage loginPage;
	HomePage homePage;
	SettingsPage settingsPage;

	public  SettingsPageTest() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	@BeforeMethod
	public void setUp() throws InterruptedException
	{
		initialization();
		//create object of login page class
		loginPage = new LoginPage();
		settingsPage= new SettingsPage();
		homePage = new HomePage();
		settingsPage = new SettingsPage();
	
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		
		settingsPage = homePage.clickOnSettingslink();
	}
	
	@Test(priority=1)
	public void verifySettingsPagelabel() throws InterruptedException {
			
		Thread.sleep(10000);
        String request_uri = null;
        String url = driver.getCurrentUrl();
        System.out.println (url);	
		
	    if (url.startsWith("https://")) {
        request_uri = url.substring(7).split("/")[3];
        } else {
        request_uri = url.split("/")[3];
		}
	    
		System.out.println (request_uri);
		
		String settingsPagelabel = settingsPage.SettingsPagelabel();
		String str1 =  settingsPagelabel.toLowerCase();
				
		System.out.println (settingsPagelabel);
		System.out.println (str1);
		
		str1 = settingsPage.removespace(str1);
		
		System.out.println (str1);
		
		assertEquals(str1, request_uri);
		Assert.assertTrue(true);		    		
	}	
				
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}	

}