package com.presidio.qa.testcases;
import static org.testng.Assert.assertEquals;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.presidio.qa.base.TestBase;
import com.presidio.qa.pages.HomePage;
import com.presidio.qa.pages.LoginPage;
import com.presidio.qa.pages.UserAccountsPage;

public class UserAccountsPageTest extends TestBase {

	LoginPage loginPage;
	HomePage homePage;
	UserAccountsPage userAccountsPage;

	public  UserAccountsPageTest() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	@BeforeMethod
	public void setUp() throws InterruptedException
	{
		initialization();
		//create object of login page class
		loginPage = new LoginPage();
		userAccountsPage= new UserAccountsPage();
		homePage = new HomePage();
	
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		
		userAccountsPage = homePage.ClicOnkUserAccountslink();
	}
	
	@Test(priority=1)
	public void verifyUserAccountsPagelabel() throws InterruptedException {
			
		Thread.sleep(10000);
        String request_uri = null;
        String url = driver.getCurrentUrl();
        String s = null;
        System.out.println (url);	
		
	    if (url.startsWith("https://")) {
        request_uri = url.substring(7).split("/")[3];
        } else {
        request_uri = url.split("/")[3];
		}
	    
		System.out.println (request_uri);
		
		String userAccountsPagelabel = userAccountsPage.UserAccountsPagelabel();
		String str1 =  userAccountsPagelabel.toLowerCase();
				
		System.out.println (userAccountsPagelabel);
		System.out.println (str1);
		
		s = userAccountsPage.Removefirstword(str1);
		
		System.out.println (s);
				
		assertEquals(s, request_uri);
		Assert.assertTrue(true);		    		
	}	
				
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}	
	
}