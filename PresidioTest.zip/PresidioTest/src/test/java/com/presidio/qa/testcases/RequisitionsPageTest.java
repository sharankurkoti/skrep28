package com.presidio.qa.testcases;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.presidio.qa.base.TestBase;
import com.presidio.qa.pages.HomePage;
import com.presidio.qa.pages.LoginPage;
import com.presidio.qa.pages.RequisitionsPage;
import com.presidio.qa.util.TestUtil;

public class RequisitionsPageTest extends TestBase {
	LoginPage loginPage;
	HomePage homePage;
	TestUtil testUtil;
	RequisitionsPage RequisitionsPage;

	public RequisitionsPageTest() 
	{
    	super(); // super class constructor to initialize properties
    }
	
	@BeforeMethod
	public void setUp() throws InterruptedException 
	{
		
		initialization();
		
		loginPage = new LoginPage();
		RequisitionsPage= new RequisitionsPage();
	
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));	
		RequisitionsPage = RequisitionsPage.ClickOnRequisitionslink();
	}

	@Test(priority=1)
	public void verifyRequisitionsPagelabel() throws InterruptedException {
			
		Thread.sleep(10000);
        String request_uri = null;
        String url = driver.getCurrentUrl();
        System.out.println (url);	
		
	    if (url.startsWith("https://")) {
        request_uri = url.substring(7).split("/")[3];
        } else {
        request_uri = url.split("/")[3];
		}
		System.out.println (request_uri);
		
		String RequisitionsPagelabel = RequisitionsPage.RequisitionsPagelabel();
		String str1 =  RequisitionsPagelabel.toLowerCase();
		
		System.out.println (RequisitionsPagelabel);
		System.out.println (str1);
						
		assertEquals(str1, request_uri);
		Assert.assertTrue(true);		    		
	}	
				
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
		
}
